import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Map;

/**
 * Main class
 */
// FREE CODE HERE
public class Main {
    public static void main(String[] args) throws IOException {

       /** MISSION POWER GRID OPTIMIZATION BELOW **/

        System.out.println("##MISSION POWER GRID OPTIMIZATION##");
        // TODO: Your code goes here
        // You are expected to read the file given as the first command-line argument to read 
        // the energy demands arriving per hour. Then, use this data to instantiate a 
        // PowerGridOptimization object. You need to call getOptimalPowerGridSolutionDP() method
        // of your PowerGridOptimization object to get the solution, and finally print it to STDOUT.

        String filename_grid = args[0];
        ArrayList<Integer> energyDemands = readEnergyDemands(filename_grid);

        PowerGridOptimization optimizer = new PowerGridOptimization(energyDemands);
        OptimalPowerGridSolution solution = optimizer.getOptimalPowerGridSolutionDP();

        System.out.println("The total number of demanded gigawatts: " + getTotalDemandedGigawatts(energyDemands));
        System.out.println("Maximum number of satisfied gigawatts: " + solution.getmaxNumberOfSatisfiedDemands());
        System.out.println("Hours at which the battery bank should be discharged: " + dischargeString(solution.getHoursToDischargeBatteriesForMaxEfficiency()));
        System.out.println("The number of unsatisfied gigawatts: " + getUnsatisfiedGigawatts(energyDemands, solution.getmaxNumberOfSatisfiedDemands()));

        System.out.println("##MISSION POWER GRID OPTIMIZATION COMPLETED##");

        /** MISSION ECO-MAINTENANCE BELOW **/

        System.out.println("##MISSION ECO-MAINTENANCE##");
        // TODO: Your code goes here
        // You are expected to read the file given as the second command-line argument to read
        // the number of available ESVs, the capacity of each available ESV, and the energy requirements 
        // of the maintenance tasks. Then, use this data to instantiate an OptimalESVDeploymentGP object.
        // You need to call getMinNumESVsToDeploy(int maxNumberOfAvailableESVs, int maxESVCapacity) method
        // of your OptimalESVDeploymentGP object to get the solution, and finally print it to STDOUT.

        // Read the eco-maintenance input file specified as the second command-line argument
        String filename_ecoMaintenance = args[1];
        ArrayList<Integer> maintenanceInput = readMaintenanceTasks(filename_ecoMaintenance);

        int numESVs = maintenanceInput.get(0);
        int esvCap = maintenanceInput.get(1);

        maintenanceInput.remove(0);
        maintenanceInput.remove(0);

        OptimalESVDeploymentGP esvDeploymentGP = new OptimalESVDeploymentGP(maintenanceInput);
        int minESVs = esvDeploymentGP.getMinNumESVsToDeploy(numESVs, esvCap);
        if (minESVs != -1) {
            System.out.println("The minimum number of ESVs to deploy: " + minESVs);
            ArrayList<ArrayList<Integer>> tasksAssignedToESVs = esvDeploymentGP.getMaintenanceTasksAssignedToESVs();
            for (int i = 0; i < tasksAssignedToESVs.size(); i++) {
                System.out.println("ESV " + (i + 1) + " tasks: " + tasksAssignedToESVs.get(i));
            }
        } else {
            System.out.println("Warning: Mission Eco-Maintenance Failed.");
        }

        System.out.println("##MISSION ECO-MAINTENANCE COMPLETED##");
    }

    public static ArrayList<Integer> readEnergyDemands(String inputFile) throws IOException {
        ArrayList<Integer> energyDemands = new ArrayList<>();
        try (BufferedReader reader = new BufferedReader(new FileReader(inputFile))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.trim().split("\\s+");
                for (String part : parts) {
                    energyDemands.add(Integer.parseInt(part));
                }
            }
        }
        return energyDemands;
    }

    public static int getTotalDemandedGigawatts(ArrayList<Integer> energyDemands) {
        int total = 0;
        for (int demand : energyDemands) {
            total += demand;
        }
        return total;
    }

    public static int getUnsatisfiedGigawatts(ArrayList<Integer> energyDemands, int satisfiedGigawatts) {
        return getTotalDemandedGigawatts(energyDemands) - satisfiedGigawatts;
    }

    public static String dischargeString(ArrayList<Integer> list) {
        if (list.size() == 0) {
            return "";
        }

        StringBuilder result = new StringBuilder(1 + (list.size() - 1) * 3);
        // They say StringBuilder is faster than OG += operator

        result.append(list.get(0));

        if (list.size() > 1) {
            for (int i = 1; i < list.size(); i++) {
                result.append(", ").append(list.get(i));
            }
        }

        return result.toString();
    }

    public static ArrayList<Integer> readMaintenanceTasks(String inputFile) throws IOException {
        ArrayList<Integer> maintenanceTasks = new ArrayList<>();

        try (BufferedReader reader = new BufferedReader(new FileReader(inputFile))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.trim().split("\\s+");
                for (String part : parts) {
                    maintenanceTasks.add(Integer.parseInt(part));
                }
            }
        }

        return maintenanceTasks;
    }
}
