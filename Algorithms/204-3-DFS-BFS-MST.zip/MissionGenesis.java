import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import java.io.File;
import java.util.ArrayList;
import java.util.List;

// Class representing the mission of Genesis
public class MissionGenesis {

    // Private fields
    private MolecularData molecularDataHuman; // Molecular data for humans
    private MolecularData molecularDataVitales; // Molecular data for Vitales

    // Getter for human molecular data
    public MolecularData getMolecularDataHuman() {
        return molecularDataHuman;
    }

    // Getter for Vitales molecular data
    public MolecularData getMolecularDataVitales() {
        return molecularDataVitales;
    }

    // Method to read XML data from the specified filename
    // This method should populate molecularDataHuman and molecularDataVitales fields once called
    public void readXML(String filename) {

        /* YOUR CODE HERE */

        try {
            File inputFile = new File(filename);
            DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
            Document doc = dBuilder.parse(inputFile);
            doc.getDocumentElement().normalize();

            parseData(doc);

        } catch (Exception e) {
            e.printStackTrace();
        }
        
    }

    private void parseData(Document doc) {
        List<Molecule> humanMolecules = new ArrayList<>();
        List<Molecule> vitalesMolecules = new ArrayList<>();
        NodeList nList = doc.getElementsByTagName("Molecule");

        for (int temp = 0; temp < nList.getLength(); temp++) {
            Node nNode = nList.item(temp);
            if (nNode.getNodeType() == Node.ELEMENT_NODE) {
                Element eElement = (Element) nNode;
                String section = nNode.getParentNode().getNodeName();
                String id = eElement.getElementsByTagName("ID").item(0).getTextContent();
                int bondStrength = Integer.parseInt(eElement.getElementsByTagName("BondStrength").item(0).getTextContent());
                NodeList bondsList = eElement.getElementsByTagName("MoleculeID");
                List<String> bonds = new ArrayList<>();
                for (int i = 0; i < bondsList.getLength(); i++) {
                    bonds.add(bondsList.item(i).getTextContent());
                }
                Molecule molecule = new Molecule(id, bondStrength, bonds);
                if (section.equals("HumanMolecularData")) {
                    humanMolecules.add(molecule);
                } else if (section.equals("VitalesMolecularData")) {
                    vitalesMolecules.add(molecule);
                }
            }
        }
        molecularDataHuman = new MolecularData(humanMolecules);
        molecularDataVitales = new MolecularData(vitalesMolecules);
    }
}