import java.util.*;

// Class representing the Mission Synthesis
public class MissionSynthesis {

    // Private fields
    private final List<MolecularStructure> humanStructures; // Molecular structures for humans
    private final ArrayList<MolecularStructure> diffStructures; // Anomalies in Vitales structures compared to humans
    private ArrayList<String> selectedHuman;
    private ArrayList<String> selectedVitales;

    // Constructor
    public MissionSynthesis(List<MolecularStructure> humanStructures, ArrayList<MolecularStructure> diffStructures) {
        this.humanStructures = humanStructures;
        this.diffStructures = diffStructures;
    }

    // Method to synthesize bonds for the serum
    public List<Bond> synthesizeSerum() {
        List<Bond> serum = new ArrayList<>();

        /* YOUR CODE HERE */ 

        ArrayList<Molecule> molecules = new ArrayList<>();

        selectedHuman = new ArrayList<>();
        selectedVitales = new ArrayList<>();

        for (MolecularStructure structure : humanStructures) {
            Molecule weakest = getWeakestMolecule(structure.getMolecules());
            molecules.add(weakest);
            selectedHuman.add(weakest.getId());
        }

        for (MolecularStructure structure : diffStructures) {
            Molecule weakest = getWeakestMolecule(structure.getMolecules());
            molecules.add(weakest);
            selectedVitales.add(weakest.getId());
        }

        Collections.sort(molecules, new BondStrengthComparator());

        Molecule weakest = molecules.get(0);
        int wkStr = weakest.getBondStrength();

        for (int i = 1; i < molecules.size(); i++) {
            Molecule current = molecules.get(i);
            serum.add(new Bond(current, weakest, (double) (wkStr + current.getBondStrength()) / 2));
        }

        return serum;
    }

    // Method to print the synthesized bonds
    public void printSynthesis(List<Bond> serum) {

        /* YOUR CODE HERE */

        System.out.printf("Typical human molecules selected for synthesis: %s%n", selectedHuman);
        System.out.printf("Vitales molecules selected for synthesis: %s%n", selectedVitales);
        System.out.println("Synthesizing the serum...");

        double total = 0;

        for (Bond bond : serum) {
            String first;
            String last;

            Molecule to = bond.getTo();
            Molecule from = bond.getFrom();
            if (to.compareTo(from) < 0) {
                first = to.getId();
                last = from.getId();
            } else {
                last = to.getId();
                first = from.getId();
            }

            System.out.printf("Forming a bond between %s - %s with strength %.2f%n", first, last, bond.getWeight());
            total += bond.getWeight();
        }

        System.out.printf("The total serum bond strength is %.2f%n", total);
    }

    private Molecule getWeakestMolecule(List<Molecule> molecules) {
        Molecule result = molecules.get(0);
        for (int i = 1; i < molecules.size(); i++) {
            Molecule current = molecules.get(i);
            if (current.getBondStrength() < result.getBondStrength()) {
                result = current;
            }
        }
        return result;
    }
}

class BondStrengthComparator implements Comparator<Molecule> {
    @Override
    public int compare(Molecule m1, Molecule m2) {
        return Integer.compare(m1.getBondStrength(), m2.getBondStrength());
    }
}