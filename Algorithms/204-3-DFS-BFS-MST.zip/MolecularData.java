import java.util.*;

// Class representing molecular data
public class MolecularData {

    // Private fields
    private final List<Molecule> molecules; // List of molecules

    // Constructor
    public MolecularData(List<Molecule> molecules) {
        this.molecules = molecules;
    }

    // Getter for molecules
    public List<Molecule> getMolecules() {
        return molecules;
    }

    // Method to identify molecular structures
    // Return the list of different molecular structures identified from the input data
    public List<MolecularStructure> identifyMolecularStructures() {
        ArrayList<MolecularStructure> structures = new ArrayList<>();

        /* YOUR CODE HERE */

        // Fixing bonds if the given file has bonds those are not bidirectional
        molecularCorrection();

        // Providing direct reach by ID
        Map<String, Molecule> moleculeMap = new HashMap<>();
        for (Molecule molecule : molecules) {
            moleculeMap.put(molecule.getId(), molecule);
        }

        // USEFUL: Set does not allow any duplicate entries, also creating a boolean list/map is a crime better kms
        Set<String> visited = new HashSet<>();

        // DFS Algorithm to find structures
        for (Molecule molecule : molecules) {
            if (!visited.contains((molecule.getId()))) {
                MolecularStructure structure = new MolecularStructure();
                dfs(molecule, visited, moleculeMap, structure);
                structures.add(structure);
            }
        }

        return structures;
    }

    // Method to print given molecular structures
    public void printMolecularStructures(List<MolecularStructure> molecularStructures, String species) {
        
        /* YOUR CODE HERE */ 

        System.out.printf("%d molecular structures have been discovered in %s.%n",
                molecularStructures.size(),
                species
        );

        for (int i = 0; i < molecularStructures.size(); i++) {
            System.out.printf("Molecules in Molecular Structure %d: %s%n",
                    i + 1,
                    molecularStructures.get(i).toString()
            );
        }

    }

    // Method to identify anomalies given a source and target molecular structure
    // Returns a list of molecular structures unique to the targetStructure only
    public static ArrayList<MolecularStructure> getVitalesAnomaly(List<MolecularStructure> sourceStructures, List<MolecularStructure> targeStructures) {
        ArrayList<MolecularStructure> anomalyList = new ArrayList<>();

        /* YOUR CODE HERE */

        for (MolecularStructure vitStructure : targeStructures) {
            boolean unique = true;
            for (MolecularStructure humStructure : sourceStructures) {
                if (vitStructure.equals(humStructure)) {
                    unique = false;
                    break;
                }
            }
            if (unique) {
                anomalyList.add(vitStructure);
            }
        }

        return anomalyList;
    }

    // Method to print Vitales anomalies
    public void printVitalesAnomaly(List<MolecularStructure> molecularStructures) {

        /* YOUR CODE HERE */ 

        System.out.println("Molecular structures unique to Vitales individuals:");
        for (MolecularStructure structure : molecularStructures) {
            System.out.println(structure.toString());
        }
    }

    private void dfs(Molecule current, Set<String> visited, Map<String, Molecule> map, MolecularStructure structure) {
        visited.add(current.getId());
        structure.addMolecule(current);
        for (String neighborId : current.getBonds()) {
            if (!visited.contains(neighborId)) {
                Molecule neighbor = map.get(neighborId);
                if (neighbor != null) {
                    dfs(neighbor, visited, map, structure);
                }
            }
        }
    }

    // Made to correct the file's uncompleted edges
    private void molecularCorrection() {
        Map<String, Molecule> moleculeMap = new HashMap<>();
        for (Molecule molecule : molecules) {
            moleculeMap.put(molecule.getId(), molecule);
        }

        for (Molecule molecule : molecules) {
            for (String bondedId : new ArrayList<>(molecule.getBonds())) {
                Molecule bonded = moleculeMap.get(bondedId);
                if (bonded != null && !bonded.getBonds().contains(molecule.getId())) {
                    bonded.getBonds().add(molecule.getId());
                }
            }
        }
    }
}
