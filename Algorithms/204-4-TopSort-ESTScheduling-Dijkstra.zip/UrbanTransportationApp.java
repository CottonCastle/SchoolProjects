import java.io.Serializable;
import java.util.*;

class UrbanTransportationApp implements Serializable {
    static final long serialVersionUID = 99L;
    
    public HyperloopTrainNetwork readHyperloopTrainNetwork(String filename) {
        HyperloopTrainNetwork hyperloopTrainNetwork = new HyperloopTrainNetwork();
        hyperloopTrainNetwork.readInput(filename);
        return hyperloopTrainNetwork;
    }

    /**
     * Function calculate the fastest route from the user's desired starting point to 
     * the desired destination point, taking into consideration the hyperloop train
     * network. 
     * @return List of RouteDirection instances
     */
    public List<RouteDirection> getFastestRouteDirections(HyperloopTrainNetwork network) {
        List<RouteDirection> routeDirections = new ArrayList<>();
        
        // TODO: Your code goes here

        // Dijkstra's algorithm
        Map<Station, List<RouteDirection>> adjList = new HashMap<>();
        Set<Station> stations = new HashSet<>();
        stations.add(network.startPoint);
        stations.add(network.destinationPoint);


        // Creating routes to set up graph
        for (TrainLine line : network.lines) {
            for (int i = 0; i < line.trainLineStations.size(); i++) {
                Station current = line.trainLineStations.get(i);
                stations.add(current);
                adjList.putIfAbsent(current, new ArrayList<>()); // avoiding duplicates
                if (i > 0) {
                    Station prev = line.trainLineStations.get(i - 1);
                    double duration = distance(prev.coordinates, current.coordinates) / network.averageTrainSpeed;
                    adjList.get(prev).add(new RouteDirection(prev.description, current.description, duration, true));
                    adjList.get(current).add(new RouteDirection(current.description, prev.description, duration, true));
                }
            }
        }

        for (Station from : stations) {
            adjList.putIfAbsent(from, new ArrayList<>());
            for (Station to : stations) {
                if (!from.equals(to)) {
                    double walkDuration = distance(from.coordinates, to.coordinates) / network.averageWalkingSpeed;
                    adjList.get(from).add(new RouteDirection(from.description, to.description, walkDuration, false));
                }
            }
        }

        PriorityQueue<RouteDirection> pQueue = new PriorityQueue<>(Comparator.comparingDouble(rd -> rd.duration));
        Map<Station, Double> distancePairs = new HashMap<>();
        Map<Station, RouteDirection> prev = new HashMap<>();
        for (Station station : stations) {
            distancePairs.put(station, Double.MAX_VALUE);
        }
        distancePairs.put(network.startPoint, 0.0);
        pQueue.add(new RouteDirection(network.startPoint.description, network.startPoint.description, 0, false));

        while (!pQueue.isEmpty()) {
            RouteDirection current = pQueue.poll();
            Station currentStation = stations.stream().filter(s -> s.description.equals(current.endStationName)).findFirst().orElse(null);

            if (currentStation == null || current.duration > distancePairs.get(currentStation)) {
                continue;
            }

            for (RouteDirection edge : adjList.get(currentStation)) {
                Station neighbor = stations.stream().filter(s -> s.description.equals(edge.endStationName)).findFirst().orElse(null);
                if (neighbor == null) continue;
                double newDist = distancePairs.get(currentStation) + edge.duration;
                if (newDist < distancePairs.get(neighbor)) {
                    distancePairs.put(neighbor, newDist);
                    prev.put(neighbor, edge);
                    pQueue.add(new RouteDirection(currentStation.description, neighbor.description, newDist, edge.trainRide));
                }
            }
        }

        Station target = network.destinationPoint;
        while (!target.equals(network.startPoint)) {
            RouteDirection edge = prev.get(target);
            if (edge == null) break; // This means there was no path found
            routeDirections.add(edge);
            target = stations.stream().filter(s -> s.description.equals(edge.startStationName)).findFirst().orElse(null);
        }
        Collections.reverse(routeDirections);

        return routeDirections;
    }

    /**
     * Function to print the route directions to STDOUT
     */
    public void printRouteDirections(List<RouteDirection> directions) {
        
        // TODO: Your code goes here

        double totalDuration = directions.stream().mapToDouble(rd -> rd.duration).sum();
        int rounded = (int) Math.round(totalDuration); // Rounding the last total result
        System.out.printf("The fastest route takes %d minute(s).\n", rounded);
        System.out.println("Directions");
        System.out.println("----------");
        for (int i = 0; i < directions.size(); i++) {
            RouteDirection rd = directions.get(i);
            String routeType = rd.trainRide ? "Get on the train from " : "Walk from ";
            // I am ternary operations, yo https://www.youtube.com/shorts/9PGyaaxxvJg
            System.out.printf("%d. %s\"%s\" to \"%s\" for %.2f minutes.%n",
                    i + 1,
                    routeType,
                    rd.startStationName,
                    rd.endStationName,
                    rd.duration);
        }
    }

    private double distance(Point a, Point b) {
        return Math.sqrt(Math.pow(a.x - b.x, 2) + Math.pow(a.y - b.y, 2));
    }
}