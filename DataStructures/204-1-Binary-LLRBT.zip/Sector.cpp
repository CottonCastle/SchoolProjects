#include "Sector.h"
#include <cmath>
#include <iostream>

// returns the letter part of the sector code
std::string getEarthComparison(int x, int y, int z) {
    std::string codeString;

    if (x > 0) {
        codeString = "R";
    } else if (x < 0) {
        codeString = "L";
    } else {
        codeString = "S";
    }

    if (y > 0) {
        codeString = codeString + "U";
    } else if (y < 0) {
        codeString = codeString + "D";
    } else {
        codeString = codeString + "S";
    }

    if (z > 0) {
        codeString = codeString + "F";
    } else if (z < 0) {
        codeString = codeString + "B";
    } else {
        codeString = codeString + "S";
    }

    return codeString;
}

// Constructor implementation

Sector::Sector(int x, int y, int z) : x(x), y(y), z(z), left(nullptr), right(nullptr), parent(nullptr), color(RED) {
        // TODO: Calculate the distance to the Earth, and generate the sector code
        distance_from_earth = sqrt(x*x + y*y + z*z);
        sector_code = std::to_string(static_cast<int>(distance_from_earth)) + getEarthComparison(x, y, z);
}

Sector::~Sector() {
    // TODO: Free any dynamically allocated memory if necessary
}

Sector& Sector::operator=(const Sector& other) {
    // TODO: Overload the assignment operator
    return *this;
}

bool Sector::operator==(const Sector& other) const {
    return (x == other.x && y == other.y && z == other.z);
}

bool Sector::operator!=(const Sector& other) const {
    return !(*this == other);
}