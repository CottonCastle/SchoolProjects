#include <queue>
#include "SpaceSectorBST.h"

using namespace std;

// Created a separate file reader to make the readSectorsFromFile look simpler
vector<vector<int>> createSectorData(const string& filename) {
    ifstream file(filename); // Constantly switching languages between java and C++
    if (!file) {
        cerr << "Error opening file." << endl;
    }

    vector<vector<int>> coordinates;
    string line;

    // Read and discard the first line
    getline(file, line);

    while (getline(file, line)) {
        istringstream iss(line);
        int x, y, z;
        char delim1, delim2; // To capture the commas

        if (!(iss >> x >> delim1 >> y >> delim2 >> z) || delim1 != ',' || delim2 != ',') {
            cerr << "Error parsing line: " << line << endl;
            continue; // Detect the wrong lines
        }
        coordinates.push_back({x, y, z});
    }

    file.close();

    return coordinates;
}

bool isDataSmaller(Sector* root, int x, int y, int z) {
    if (x < root->x) {
        return true;
    } else if (x > root->x) {
        return false;
    } else {
        // X is equal
        if (y < root->y) {
            return true;
        } else if (y > root->y) {
            return false;
        } else {
            // and Y is equal too
            if (z < root->z) {
                return true;
            } else if(z > root->z) {
                return false; // Either z is greater or all values are equal
            } else {
                return false;
            }
        }
    }
}

bool isDataEqual(Sector* root, int x, int y, int z) {
    return (root->x == x && root->y == y && root->z == z);
}

Sector* getNewSector(int x, int y, int z) {
    Sector* node = new Sector(x, y, z);
    return node;
}

void insertSector(Sector*& node, int x, int y, int z) { // This is recursive
    if(node == nullptr) {
        node = getNewSector(x, y, z); // when it reaches the end inserts the new node
        return;
    } else if(isDataSmaller(node, x, y, z)) {
        insertSector(node->left, x, y, z);
    } else {
        insertSector(node->right, x, y, z);
    }
}

// wanted to make efficient and different somehow but too much trouble so just traverse

Sector* breadthFirstSearch(Sector* root, const string& code) {
    if (root == nullptr) {
        return nullptr;
    }

    std::queue<Sector*> queue;
    queue.push(root);

    while (!queue.empty()) {
        Sector* current = queue.front();
        queue.pop();

        if (current->sector_code == code) {
            return current;
        }

        if (current->left != nullptr) {
            queue.push(current->left);
        }
        if (current->right != nullptr) {
            queue.push(current->right);
        }
    }

    return nullptr; // Node not found
}

Sector* getLefty(Sector* node) {
    if (node == nullptr) {
        return nullptr;
    }
    if(node->left == nullptr) {
        return node;
    } else {
        return getLefty(node->left);
    }
}

Sector* deleteByCoordinates(Sector* node ,int x, int y, int z) {
    if(node == nullptr) { return node;
    } else if (isDataEqual(node, x, y, z)) {
        if(node->left == nullptr && node->right == nullptr) {
            delete node;
            node = nullptr;
        } else if(node->left == nullptr) {
            Sector* temp = node;
            node = node->right;
            delete temp;
        } else if(node->right == nullptr) {
            Sector* temp = node;
            node = node->left;
            delete temp;
        } else {
            Sector* temp = getLefty(node->right);
            node-> x = temp->x;
            node->y = temp->y;
            node->z = temp->z;
            node->sector_code = temp->sector_code;
            node->distance_from_earth = temp->distance_from_earth;
            node->right = deleteByCoordinates(node->right, temp->x, temp->y, temp->z);
        }
    } else if(isDataSmaller(node, x, y, z)) {
        node->left = deleteByCoordinates(node->left, x, y, z);
    } else if(!isDataSmaller(node, x, y, z)) {
        node->right = deleteByCoordinates(node->right, x, y, z);
    }
    return node;
}

void inorderTraversal(Sector* node) {
    if (node == nullptr) { return; }
    inorderTraversal(node->left);
    cout << node->sector_code << endl;
    inorderTraversal(node->right);
}

void preorderTraversal(Sector* node) {
    if (node == nullptr) { return; }
    cout << node->sector_code << endl;
    preorderTraversal(node->left);
    preorderTraversal(node->right);
}

void postorderTraversal(Sector* node) {
    if (node == nullptr) { return; }
    postorderTraversal(node->left);
    postorderTraversal(node->right);
    cout << node->sector_code << endl;
}

// Deleting in post-order traversal to avoid leaks
void deleteBST(Sector* node) {
    if (node != nullptr) {
        deleteBST(node->left);
        deleteBST(node->right);
        delete node;
    }
}

vector<Sector*> getThePath(vector<Sector*> path, Sector* node, int x, int y, int z) {
    if(node == nullptr) {
        return {};
    }
    path.emplace_back(node);
    if(node->x == x && node->y == y && node->z == z) {
        return path;
    }
    if(isDataSmaller(node, x, y, z)) {
        vector<Sector*> leftPath = getThePath(path, node->left, x, y, z);
        if (!leftPath.empty()) {
            return leftPath;
        }
    } else {
        vector<Sector*> rightPath = getThePath(path, node->right, x, y, z);
        if (!rightPath.empty()) {
            return rightPath;
        }
    }

    return {}; // Return an empty one as nothing happens
}

SpaceSectorBST::SpaceSectorBST() : root(nullptr) {}

SpaceSectorBST::~SpaceSectorBST() {
    // Free any dynamically allocated memory in this class.
    deleteBST(root);
}

void SpaceSectorBST::readSectorsFromFile(const std::string& filename) {
    // TODO: read the sectors from the input file and insert them into the BST sector map
    // according to the given comparison critera based on the sector coordinates.
    // Step 1: Get the sector data as
    vector<vector<int>> data = createSectorData(filename);
    // Step 2: for loop:DDDDD
    int i = 0;
    for (const auto& coordinates : data) {
        insertSectorByCoordinates(
                coordinates[0], // X
                coordinates[1], // Y
                coordinates[2]);// Z
    }
}

void SpaceSectorBST::insertSectorByCoordinates(int x, int y, int z) {
    // Instantiate and insert a new sector into the space sector BST map according to the 
    // coordinates-based comparison criteria.
    insertSector(root, x, y, z);
}

void SpaceSectorBST::deleteSector(const std::string& sector_code) {
    // TODO: Delete the sector given by its sector_code from the BST.
    Sector* target = breadthFirstSearch(root, sector_code);
    if(target != nullptr) {
        root = deleteByCoordinates(root, target->x, target->y, target->z);
    }
}

void SpaceSectorBST::displaySectorsInOrder() {
    // TODO: Traverse the space sector BST map in-order and print the sectors 
    // to STDOUT in the given format.
    cout << "Space sectors inorder traversal:\n";
    inorderTraversal(root);
    cout << endl;
}

void SpaceSectorBST::displaySectorsPreOrder() {
    // TODO: Traverse the space sector BST map in pre-order traversal and print 
    // the sectors to STDOUT in the given format.
    cout << "Space sectors preorder traversal:\n";
    preorderTraversal(root);
    cout << endl;
}

void SpaceSectorBST::displaySectorsPostOrder() {
    // TODO: Traverse the space sector BST map in post-order traversal and print 
    // the sectors to STDOUT in the given format.
    cout << "Space sectors postorder traversal:\n";
    postorderTraversal(root);
    cout << endl;
}

std::vector<Sector*> SpaceSectorBST::getStellarPath(const std::string& sector_code) {
    std::vector<Sector*> path;
    // TODO: Find the path from the Earth to the destination sector given by its
    // sector_code, and return a vector of pointers to the Sector nodes that are on
    // the path. Make sure that there are no duplicate Sector nodes in the path!
    Sector* target = breadthFirstSearch(root, sector_code);
    if (target != nullptr) {
        path = getThePath(path, root, target->x, target->y, target->z);
    }
    return path;
}

void SpaceSectorBST::printStellarPath(const std::vector<Sector*>& path) {
    // TODO: Print the stellar path obtained from the getStellarPath() function 
    // to STDOUT in the given format.
    if(path.empty()) {
        cout << "A path to Dr. Elara could not be found.";
    } else {
        int i = 0;
        for (const auto &sector: path) {
            if (i == 0) {
                cout << "The stellar path to Dr. Elara: ";
            } else {
                cout << "->";
            }
            cout << sector->sector_code;
            i++;
        }
    }
    cout << endl;
}