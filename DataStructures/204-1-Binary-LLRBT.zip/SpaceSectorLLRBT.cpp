#include <queue>
#include <stack>
#include "SpaceSectorLLRBT.h"

using namespace std;

vector<vector<int>> createLLRBTData(const string& filename) {
    ifstream file(filename); // Constantly switching languages between java and C++
    if (!file) {
        cerr << "Error opening file." << endl;
    }

    vector<vector<int>> coordinates;
    string line;

    // Read and discard the first line
    getline(file, line);

    while (getline(file, line)) {
        istringstream iss(line);
        int x, y, z;
        char delim1, delim2; // To capture the commas

        if (!(iss >> x >> delim1 >> y >> delim2 >> z) || delim1 != ',' || delim2 != ',') {
            cerr << "Error parsing line: " << line << endl;
            continue; // Detect the wrong lines
        }
        coordinates.push_back({x, y, z});
    }

    file.close();

    return coordinates;
}

bool isDataSmall(Sector* root, int x, int y, int z) {
    if (x < root->x) {
        return true;
    } else if (x > root->x) {
        return false;
    } else {
        // X is equal
        if (y < root->y) {
            return true;
        } else if (y > root->y) {
            return false;
        } else {
            // and Y is equal too
            if (z < root->z) {
                return true;
            } else if(z > root->z) {
                return false; // Either z is greater or all values are equal
            } else {
                return false;
            }
        }
    }
}

Sector* getNewNode(int x, int y, int z) {
    Sector* node = new Sector(x, y, z);
    return node;
}

// will be used for case 1: right child red, left child black(or null)
Sector* leftRotate(Sector* node) {
    Sector* rightChild = node->right;
    Sector* rightLeftChild = rightChild->left;

    rightChild->left = node;
    node->right = rightLeftChild;

    rightChild->parent = node->parent;
    node->parent = rightChild;
    if (rightLeftChild != nullptr) {
        rightLeftChild->parent = node;
    }

    return rightChild;
}
// will be used for case 2: left child and left grandchild are red
Sector* rightRotate(Sector* node) {
    Sector* leftChild = node->left;
    Sector* leftRightChild = leftChild->right;

    leftChild->right = node;
    node->left = leftRightChild;

    leftChild->parent = node->parent;
    node->parent = leftChild;
    if (leftRightChild != nullptr) {
        leftRightChild->parent = node;
    }

    return leftChild;
}
// will be used for case 3: double red children
void invertColors(Sector* node) {
    node->color = !(node->color);

    node->left->color = BLACK;
    node->right->color = BLACK;
}

void swapColor(Sector* first, Sector* second) {
    bool temp = first->color;
    first->color = second->color;
    second->color = temp;
}

int checkRed(Sector* node) {
    if (node == nullptr) { return 0; }
    return (node->color);
}

string getColorText(Sector* node) {
    if (node->color) { return "RED sector: "; }
    return "BLACK sector: ";
}

Sector* insertLLRBT(Sector* node, Sector* parent, int x, int y, int z) {
    if (node == nullptr) {
        node = getNewNode(x, y, z); // making the root black will be done in byCoordinates function
        node->parent = parent;
        return node;
    } else if(isDataSmall(node, x, y, z)) {
        node->left = insertLLRBT(node->left, node, x, y, z);
    } else if(!isDataSmall(node, x, y, z)) {
        node->right = insertLLRBT(node->right, node, x, y, z);
    } else {
        return node;
    }
    // different situation as mentioned above
    if (checkRed(node->right) && !checkRed(node->left)) {
        node = leftRotate(node);
        swapColor(node, node->left);
    }

    if (checkRed(node->left) && checkRed(node->left->left)) {
        node = rightRotate(node);
        swapColor(node, node->right);
    }

    if (checkRed(node->left) && checkRed(node->right)) {
        invertColors(node);
    }
    return node;
}

void inorderTraversalLLRBT(Sector* node) {
    if (node == nullptr) { return; }
    inorderTraversalLLRBT(node->left);
    cout << getColorText(node);
    cout << node->sector_code << endl;
    inorderTraversalLLRBT(node->right);
}

void preorderTraversalLLRBT(Sector* node) {
    if (node == nullptr) { return; }
    cout << getColorText(node);
    cout << node->sector_code << endl;
    preorderTraversalLLRBT(node->left);
    preorderTraversalLLRBT(node->right);
}

void postorderTraversalLLRBT(Sector* node) {
    if (node == nullptr) { return; }
    postorderTraversalLLRBT(node->left);
    postorderTraversalLLRBT(node->right);
    cout << getColorText(node);
    cout << node->sector_code << endl;
}

void deleteLLRBT(Sector* node) {
    if (node != nullptr) {
        deleteLLRBT(node->left);
        deleteLLRBT(node->right);
        delete node;
    }
}

Sector* breadthSearch(Sector* root, const string& code) {
    if (root == nullptr) {
        return nullptr; // tree does not even exist
    }

    std::queue<Sector*> queue;
    queue.push(root);

    while (!queue.empty()) {
        Sector* current = queue.front();
        queue.pop();

        if (current->sector_code == code) {
            return current;
        }

        if (current->left != nullptr) {
            queue.push(current->left);
        }
        if (current->right != nullptr) {
            queue.push(current->right);
        }
    }

    return nullptr; // Node not found
}

SpaceSectorLLRBT::SpaceSectorLLRBT() : root(nullptr) {}

void SpaceSectorLLRBT::readSectorsFromFile(const std::string& filename) {
    // TODO: read the sectors from the input file and insert them into the LLRBT sector map
    // according to the given comparison critera based on the sector coordinates.
    // Step 1: Get the sector data as
    vector<vector<int>> data = createLLRBTData(filename);
    // Step 2: for loop:DDDDD
    int i = 0;
    for (const auto& coordinates : data) {
        insertSectorByCoordinates(
                coordinates[0], // X
                coordinates[1], // Y
                coordinates[2]);// Z
    }
}

stack<Sector*> getParents(stack<Sector*> stack, Sector* node) {
    stack.push(node);
    if(node->parent == nullptr) {
        return stack;
    }
    return getParents(stack ,node->parent);
}

vector<Sector*> combinePaths(stack<Sector*> targetPath, stack<Sector*> earthPath) {
    Sector* LCN; // lowest common neighbor
    vector<Sector*> combinedPath;
    while (!targetPath.empty() && !earthPath.empty() && (targetPath.top() == earthPath.top())) {
        LCN = targetPath.top();
        targetPath.pop();
        earthPath.pop();
    }
    targetPath.push(LCN);
    while (!earthPath.empty()) {
        targetPath.push(earthPath.top());
        earthPath.pop();
    }
    while (!targetPath.empty()) {
        combinedPath.emplace_back(targetPath.top());
        targetPath.pop();
    }
    return combinedPath;
}

// Remember to handle memory deallocation properly in the destructor.
SpaceSectorLLRBT::~SpaceSectorLLRBT() {
    // TODO: Free any dynamically allocated memory in this class.
    deleteLLRBT(root);
}

void SpaceSectorLLRBT::insertSectorByCoordinates(int x, int y, int z) {
    // TODO: Instantiate and insert a new sector into the space sector LLRBT map 
    // according to the coordinates-based comparison criteria.
    root = insertLLRBT(root, nullptr, x, y, z);
    if (root != nullptr) {
        root->color = BLACK;
    }
}

void SpaceSectorLLRBT::displaySectorsInOrder() {
    // TODO: Traverse the space sector LLRBT map in-order and print the sectors 
    // to STDOUT in the given format.
    cout << "Space sectors inorder traversal:\n";
    inorderTraversalLLRBT(root);
    cout << endl;
}

void SpaceSectorLLRBT::displaySectorsPreOrder() {
    // TODO: Traverse the space sector LLRBT map in pre-order traversal and print 
    // the sectors to STDOUT in the given format.
    cout << "Space sectors preorder traversal:\n";
    preorderTraversalLLRBT(root);
    cout << endl;
}

void SpaceSectorLLRBT::displaySectorsPostOrder() {
    // TODO: Traverse the space sector LLRBT map in post-order traversal and print 
    // the sectors to STDOUT in the given format.
    cout << "Space sectors postorder traversal:\n";
    postorderTraversalLLRBT(root);
    cout << endl;
}

std::vector<Sector*> SpaceSectorLLRBT::getStellarPath(const std::string& sector_code) {
    std::vector<Sector*> path;
    // TODO: Find the path from the Earth to the destination sector given by its
    // sector_code, and return a vector of pointers to the Sector nodes that are on
    // the path. Make sure that there are no duplicate Sector nodes in the path!
    Sector* target = breadthSearch(root, sector_code);
    Sector* earth = breadthSearch(root, "0SSS");
    if (target != nullptr && earth != nullptr) {
        stack<Sector*> targetPath;
        targetPath = getParents(targetPath, target);
        stack<Sector*> earthPath;
        earthPath = getParents(earthPath, earth);
        path = combinePaths(targetPath, earthPath);
    }
    return path;
}

void SpaceSectorLLRBT::printStellarPath(const std::vector<Sector*>& path) {
    // TODO: Print the stellar path obtained from the getStellarPath() function 
    // to STDOUT in the given format.
    if(path.empty()) {
        cout << "A path to Dr. Elara could not be found.";
    } else {
        int i = 0;
        for (const auto &sector: path) {
            if (i == 0) {
                cout << "The stellar path to Dr. Elara: ";
            } else {
                cout << "->";
            }
            cout << sector->sector_code;
            i++;
        }
    }
    cout << endl;
}