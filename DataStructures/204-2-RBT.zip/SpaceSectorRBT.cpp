#include <queue>
#include <stack>
#include "SpaceSectorRBT.h"

using namespace std;

vector<vector<int>> createRBTData(const string& filename) {
    ifstream file(filename); // Constantly switching languages between java and C++
    if (!file) {
        cerr << "Error opening file." << endl;
    }

    vector<vector<int>> coordinates;
    string line;

    // Read and discard the first line
    getline(file, line);

    while (getline(file, line)) {
        istringstream iss(line);
        int x, y, z;
        char delim1, delim2; // To capture the commas

        if (!(iss >> x >> delim1 >> y >> delim2 >> z) || delim1 != ',' || delim2 != ',') {
            cerr << "Error parsing line: " << line << endl;
            continue; // Detect the wrong lines
        }
        coordinates.push_back({x, y, z});
    }

    file.close();

    return coordinates;
}

bool isDataSmall(Sector* root, int x, int y, int z) {
    if (x < root->x) {
        return true;
    } else if (x > root->x) {
        return false;
    } else {
        // X is equal
        if (y < root->y) {
            return true;
        } else if (y > root->y) {
            return false;
        } else {
            // and Y is equal too
            if (z < root->z) {
                return true;
            } else if(z > root->z) {
                return false; // Either z is greater or all values are equal
            } else {
                return false;
            }
        }
    }
}

string getColorText(Sector* node) {
    if (node->color) { return "RED sector: "; }
    return "BLACK sector: ";
}

void inorderTraversalRBT(Sector* node) {
    if (node == nullptr) { return; }
    inorderTraversalRBT(node->left);
    cout << getColorText(node);
    cout << node->sector_code << endl;
    inorderTraversalRBT(node->right);
}

void preorderTraversalRBT(Sector* node) {
    if (node == nullptr) { return; }
    cout << getColorText(node);
    cout << node->sector_code << endl;
    preorderTraversalRBT(node->left);
    preorderTraversalRBT(node->right);
}

void postorderTraversalRBT(Sector* node) {
    if (node == nullptr) { return; }
    postorderTraversalRBT(node->left);
    postorderTraversalRBT(node->right);
    cout << getColorText(node);
    cout << node->sector_code << endl;
}

void deleteRBT(Sector* node) {
    if (node != nullptr) {
        deleteRBT(node->left);
        deleteRBT(node->right);
        delete node;
    }
}

Sector* breadthSearch(Sector* root, const string& code) {
    if (root == nullptr) {
        return nullptr; // tree does not even exist
    }

    std::queue<Sector*> queue;
    queue.push(root);

    while (!queue.empty()) {
        Sector* current = queue.front();
        queue.pop();

        if (current->sector_code == code) {
            return current;
        }

        if (current->left != nullptr) {
            queue.push(current->left);
        }
        if (current->right != nullptr) {
            queue.push(current->right);
        }
    }

    return nullptr; // Node not found
}

stack<Sector*> getParents(stack<Sector*> stack, Sector* node) {
    stack.push(node);
    if(node->parent == nullptr) {
        return stack;
    }
    return getParents(stack ,node->parent);
}

vector<Sector*> combinePaths(stack<Sector*> targetPath, stack<Sector*> earthPath) {
    Sector* LCN; // lowest common neighbor
    vector<Sector*> combinedPath;
    while (!targetPath.empty() && !earthPath.empty() && (targetPath.top() == earthPath.top())) {
        LCN = targetPath.top();
        targetPath.pop();
        earthPath.pop();
    }
    targetPath.push(LCN);
    while (!earthPath.empty()) {
        targetPath.push(earthPath.top());
        earthPath.pop();
    }
    while (!targetPath.empty()) {
        combinedPath.emplace_back(targetPath.top());
        targetPath.pop();
    }
    return combinedPath;
}

void SpaceSectorRBT::rotateLeft(Sector *&node) {
    Sector *right_child = node->right;
    node->right = right_child->left;
    if (node->right != nullptr) {
        node->right->parent = node;
    }
    right_child->parent = node->parent;
    if (node->parent == nullptr) {
        root = right_child;
    } else if (node == node->parent->left) {
        node->parent->left = right_child;
    } else {
        node->parent->right = right_child;
    }
    right_child->left = node;
    node->parent = right_child;
}

void SpaceSectorRBT::rotateRight(Sector *&node) {
    Sector *left_child = node->left;
    node->left = left_child->right;
    if (node->left != nullptr) {
        node->left->parent = node;
    }
    left_child->parent = node->parent;
    if (node->parent == nullptr) {
        root = left_child;
    } else if (node == node->parent->left) {
        node->parent->left = left_child;
    } else {
        node->parent->right = left_child;
    }
    left_child->right = node;
    node->parent = left_child;
}

void SpaceSectorRBT::fixInsertion(Sector *&node) {
    Sector* parent = nullptr;
    Sector* grandpa = nullptr;

    while ((node != root) && (node->color != BLACK) && (node->parent->color == RED)) {
        parent = node->parent;
        grandpa = node->parent->parent;
        // Parent of the node is left child of grandparent of the node
        if (parent == grandpa->left) {
            Sector* uncle = grandpa->right;

            // The uncle of the node is red
            if (uncle != nullptr && uncle->color == RED) {
                grandpa->color = RED;
                parent->color = BLACK;
                uncle->color = BLACK;
                node = grandpa;
            } else { // The node is right child of its parent
                if (node == parent->right) {
                    rotateLeft(parent);
                    node = parent;
                    parent = node->parent;
                }
                // Node is left child of its parent
                rotateRight(grandpa);
                swap(parent->color, grandpa->color);
                node = parent;
            }
        } else { // Parent of the node is right child of grandparent of the node
            Sector *uncle_pt = grandpa->left;
            if ((uncle_pt != nullptr) && (uncle_pt->color == RED)) { // The uncle of node is also red
                grandpa->color = RED;
                parent->color = BLACK;
                uncle_pt->color = BLACK;
                node = grandpa;
            } else {
                // The node is left child of its parent
                if (node == parent->left) {
                    rotateRight(parent);
                    node = parent;
                    parent = node->parent;
                }

                // The node is right child of its parent
                rotateLeft(grandpa);
                swap(parent->color, grandpa->color);
                node = parent;
            }
        }
    }
    root->color = BLACK;
}

Sector* insertBST(Sector *&root, Sector *&node) {
    // Normal BST insertion
    if (root == nullptr) return node;

    if (isDataSmall(root, node->x, node->y, node->z)) {
        root->left = insertBST(root->left, node);
        root->left->parent = root;
    } else if (!isDataSmall(root, node->x, node->y, node->z)) {
        root->right = insertBST(root->right, node);
        root->right->parent = root;
    }

    return root;
}

SpaceSectorRBT::SpaceSectorRBT() : root(nullptr) {}

void SpaceSectorRBT::readSectorsFromFile(const std::string& filename) {
    // TODO: read the sectors from the input file and insert them into the RBT sector map
    // according to the given comparison critera based on the sector coordinates.
    vector<vector<int>> data = createRBTData(filename);
    int i = 0;
    for(const auto& coordinates : data) {
        insertSectorByCoordinates(
                coordinates[0],
                coordinates[1],
                coordinates[2]);
    }
}

// Remember to handle memory deallocation properly in the destructor.
SpaceSectorRBT::~SpaceSectorRBT() {
    // TODO: Free any dynamically allocated memory in this class.
    deleteRBT(root);
}

void SpaceSectorRBT::insertSectorByCoordinates(int x, int y, int z) {
    // TODO: Instantiate and insert a new sector into the space sector RBT map 
    // according to the coordinates-based comparison criteria.
    Sector* newNode = new Sector(x, y, z);
    root = insertBST(root, newNode);
    fixInsertion(newNode);
}

void SpaceSectorRBT::displaySectorsInOrder() {
    // TODO: Traverse the space sector RBT map in-order and print the sectors 
    // to STDOUT in the given format.
    cout << "Space sectors inorder traversal:\n";
    inorderTraversalRBT(root);
    cout << endl;
}

void SpaceSectorRBT::displaySectorsPreOrder() {
    // TODO: Traverse the space sector RBT map in pre-order traversal and print 
    // the sectors to STDOUT in the given format.
    cout << "Space sectors preorder traversal:\n";
    preorderTraversalRBT(root);
    cout << endl;
}

void SpaceSectorRBT::displaySectorsPostOrder() {
    // TODO: Traverse the space sector RBT map in post-order traversal and print 
    // the sectors to STDOUT in the given format.
    cout << "Space sectors postorder traversal:\n";
    postorderTraversalRBT(root);
    cout << endl;
}

std::vector<Sector*> SpaceSectorRBT::getStellarPath(const std::string& sector_code) {
    std::vector<Sector*> path;
    // TODO: Find the path from the Earth to the destination sector given by its
    // sector_code, and return a vector of pointers to the Sector nodes that are on
    // the path. Make sure that there are no duplicate Sector nodes in the path!
    Sector* target = breadthSearch(root, sector_code);
    Sector* earth = breadthSearch(root, "0SSS");
    if (target != nullptr && earth != nullptr) {
        stack<Sector*> targetPath;
        targetPath = getParents(targetPath, target);
        stack<Sector*> earthPath;
        earthPath = getParents(earthPath, earth);
        path = combinePaths(targetPath, earthPath);
    }
    return path;
}

void SpaceSectorRBT::printStellarPath(const std::vector<Sector*>& path) {
    // TODO: Print the stellar path obtained from the getStellarPath() function 
    // to STDOUT in the given format.
    if(path.empty()) {
        cout << "A path to Dr. Elara could not be found.";
    } else {
        int i = 0;
        for (const auto &sector: path) {
            if (i == 0) {
                cout << "The stellar path to Dr. Elara: ";
            } else {
                cout << "->";
            }
            cout << sector->sector_code;
            i++;
        }
    }
    cout << endl;
}