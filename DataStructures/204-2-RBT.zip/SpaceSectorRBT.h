#ifndef SPACESECTORRBT_H
#define SPACESECTORRBT_H

#include "Sector.h"
#include <iostream>
#include <fstream>  
#include <sstream>
#include <vector>

class SpaceSectorRBT {
public:
    Sector* root;
    SpaceSectorRBT();
    ~SpaceSectorRBT();
    void readSectorsFromFile(const std::string& filename);
    void insertSectorByCoordinates(int x, int y, int z);
    void displaySectorsInOrder();
    void displaySectorsPreOrder();
    void displaySectorsPostOrder();
    std::vector<Sector*> getStellarPath(const std::string& sector_code);
    void printStellarPath(const std::vector<Sector*>& path);

    // Extra needed functions
    void fixInsertion(Sector *&node);
    void rotateRight(Sector *&node);
    void rotateLeft(Sector *&node);
};

#endif // SPACESECTORRBT_H
