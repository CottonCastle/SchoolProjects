import java.util.Date;

public class Bill {
    private String purchaseName;
    private int quantity;
    private double cost;
    private Date fromDate;
    private Date toDate;

    Bill(String purchaseName, int quantity, double cost, Date fromDate, Date toDate) {
        setPurchaseName(purchaseName);
        setQuantity(quantity);
        setCost(cost);
        setFromDate(fromDate);
        setToDate(toDate);
    }

    public String getPurchaseName() {
        return purchaseName;
    }

    public void setPurchaseName(String purchaseName) {
        this.purchaseName = purchaseName;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public double getCost() {
        return cost;
    }

    public void setCost(double cost) {
        this.cost = cost;
    }

    public Date getFromDate() {
        return fromDate;
    }

    public void setFromDate(Date fromDate) {
        this.fromDate = fromDate;
    }

    public Date getToDate() {
        return toDate;
    }

    public void setToDate(Date toDate) {
        this.toDate = toDate;
    }
}
