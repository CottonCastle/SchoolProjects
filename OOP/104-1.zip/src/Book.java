/*
name:   The book's name or type
prices: The data including date-price info
 */

import java.util.ArrayList;

public class Book {
    private String name;
    private ArrayList<Price> prices;

    Book() {
        prices = new ArrayList<>();
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public ArrayList<Price> getPrices() {
        return prices;
    }
}
