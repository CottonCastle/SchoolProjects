import java.util.ArrayList;
import java.util.Map;

public class Launch {
    public static void launch(String orderPath, String catPath) {
        WriteFile.flush();
        ArrayList<Book> products = ReadFromFile.readPriceCatalog(catPath);
        Order[] orders = ReadFromFile.readPurchaseOrder(orderPath);
        int customerNo = 1;

        for (Order order: orders) {
            ArrayList<Bill> bills = new ArrayList<>();
            for (Map.Entry<String, Integer> pair: order.getPurchases().entrySet()) {

                String orderName = pair.getKey();
                int quantity = pair.getValue();

                for (Book product: products) {
                    for (Price price : product.getPrices()) {
                        if (product.getName().equals(orderName) &&
                                order.getMembership().equals(price.getMembership()) &&
                                order.getDate().after(price.getFromDate()) &&
                                order.getDate().before(price.getToDate())) {

                                Bill bill = new Bill(orderName, quantity, price.getPrice(), price.getFromDate(), price.getToDate());
                                bills.add(bill);
                            }
                        }

                }
            }
            WriteFile.printBill(customerNo, order.getName(), order.getMembership(), order.getDate(), bills);
            customerNo++;
        }
        WriteFile.close();
    }
}
