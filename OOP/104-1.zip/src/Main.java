public class Main {
    public static void main(String[] args) {
        Launch.launch(args[0], args[1]);
    }
}
