import java.util.Date;
import java.util.LinkedHashMap;

public class Order {
    private String name;
    private String membership;
    private String productName;
    private Date date;
    private LinkedHashMap<String, Integer> purchases;

    Order() {
        purchases = new LinkedHashMap<>();
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getMembership() {
        return membership;
    }

    public void setMembership(String membership) {
        this.membership = membership;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public LinkedHashMap<String, Integer> getPurchases() {
        return purchases;
    }

    public void setPurchases(LinkedHashMap<String, Integer> purchases) {
        this.purchases = purchases;
    }
}
