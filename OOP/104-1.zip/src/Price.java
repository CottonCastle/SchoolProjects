import java.util.Date;

/*
fromDate:   The date the price is being applied since
toDate:     The date until the price is being applied to
price:      The price being applied
 */

public class Price {
    private Date fromDate;
    private Date toDate;
    private String membership;
    private double price;

    Price(Date fromDate, Date toDate, String membership, double price) {
        setFromDate(fromDate);
        setToDate(toDate);
        setMembership(membership);
        setPrice(price);
    }

    public Date getFromDate() {
        return fromDate;
    }

    public void setFromDate(Date fromDate) {
        this.fromDate = fromDate;
    }

    public Date getToDate() {
        return toDate;
    }

    public void setToDate(Date toDate) {
        this.toDate = toDate;
    }

    public String getMembership() {
        return membership;
    }

    public void setMembership(String membership) {
        this.membership = membership;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }
}
