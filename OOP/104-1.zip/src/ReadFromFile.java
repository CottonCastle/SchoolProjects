import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.ArrayList;

/*
readLines: Reads the txt file and returns an array of its lines
readPriceCatalog: Takes the lines formats them according to the formatter and returns an array of strings made by lines
tabSeparator: Formats the taken string and turns them into a usable array by removing tabs
 */

public class ReadFromFile {
    static final SimpleDateFormat dateInputFormatter = new SimpleDateFormat("dd.MM.yyyy");

    public static String[] readFile(String path) {
        try {
            int i = 0;
            int length = Files.readAllLines(Paths.get(path)).size();
            String[] results = new String[length];

            for (String line: Files.readAllLines(Paths.get(path))) {
                results[i++] = line;
            }

            return results;
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        }
    }

    // Reads the lines for the use of read methods
    private static String[] readLines(String path) {
        try {
            int i = 0;
            int length = Files.readAllLines(Paths.get(path)).size();
            String[] lineResults = new String[length];

            for (String line : Files.readAllLines(Paths.get(path))) {
                lineResults[i++] = line;
            }

            return lineResults;
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        }
    }
    // Separates the data and returns as an array
    private static String[] tabSeparator(String line) {
        return line.split("\t");
    }
    // checks if the membership is valis
    private static void isValidMembership(String membership) {
        if (!(membership.equals("Premium") ||
            membership.equals("Standard") ||
            membership.equals("Basic"))
        ) {
            throw new IllegalArgumentException("Not a valid membership type!");
        }
    }

    public static ArrayList<Book> readPriceCatalog(String path) {
        ArrayList<Book> Books = new ArrayList<>();
        String[] lines = readLines(path);

        for (String line: lines) {
            String[] data = tabSeparator(line);
            // Setting the data
            String name = data[0];
            String membership = data[1];
            isValidMembership(membership);
            Date fromDate = null;
            Date toDate = null;
            try {
                fromDate = dateInputFormatter.parse(data[2]);
                toDate = dateInputFormatter.parse(data[3]);
            } catch (ParseException e) {
                throw new RuntimeException(e);
            }

            double price = Double.parseDouble(data[4]);

            int bookCount = Books.size();
            if (bookCount != 0) {
                Price newPrice = new Price(fromDate, toDate, membership, price);
                for (int i = 0; i < bookCount; i++) {
                    if (Books.get(i).getName().equals(name)) {
                        boolean addPrice = true;
                        for (Price existingPrice: Books.get(i).getPrices()) {
                            if (existingPrice.getFromDate().equals(fromDate) &&
                                    existingPrice.getToDate().equals(toDate) &&
                                    existingPrice.getMembership().equals(membership)
                            ) {
                                addPrice = false;
                            }
                        }
                        if (addPrice) {
                            Books.get(i).getPrices().add(newPrice);
                        }
                    } else if(i == bookCount -1) {
                        Book newBook = new Book();
                        newBook.setName(name);
                        newBook.getPrices().add(newPrice);
                        Books.add(newBook);
                    }
                }
            } else {
                Book newBook = new Book();
                newBook.setName(name);
                Price newPrice = new Price(fromDate, toDate, membership, price);
                newBook.getPrices().add(newPrice);
                Books.add(newBook);
            }
        }
        return Books;
    }

    public static Order[] readPurchaseOrder(String path) {
        String[] lines = readLines(path);
        Order[] orders = new Order[lines.length];
        int lineCount = 0;
        for (String line: lines) {
            Order order = new Order();
            String[] data = tabSeparator(line);

            String customerName = data[0];
            String membership = data[1];
            isValidMembership(membership);
            Date date = null;
            try {
                date = dateInputFormatter.parse(data[2]);
            } catch (ParseException e) {
                throw new RuntimeException(e);
            }

            order.setName(customerName);
            order.setMembership(membership);
            order.setDate(date);
            for (int i = 4; i <= data.length; i += 2) {
                order.getPurchases().put(data[i-1], Integer.valueOf(data[i]));
            }
            orders[lineCount] = order;
            lineCount++;
        }
        return orders;
    }
}
