import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;

public class WriteFile {
    private static final String path = "output.txt";
    private static final BufferedWriter writer;

    static {
        try {
            writer = new BufferedWriter(new FileWriter(path));
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    public static void flush() {
        try {
            writer.flush();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    public static void close() {
        try {
            writer.close();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    public static void printBill(int customerNo, String customerName, String membership, Date date, ArrayList<Bill> bills) {
        Locale.setDefault(Locale.US);
        double totalCost = 0;
        try {
            writer.append("------------Bill for Customer " + customerNo + "-------------\n");
            writer.append("Customer: " + customerName);
            writer.append("\nMembership Type: " + membership);
            writer.append("\nDate: " + ReadFromFile.dateInputFormatter.format(date));
            writer.append("\n\nItems Purchased:\n");
            for (Bill bill: bills) {
                writer.append(String.format("%s (Qty: %d) - %.2f each\n" +
                        "(Valid from %s to %s)\n" +
                        "Subtotal: %.2f\n",
                        bill.getPurchaseName(), bill.getQuantity(), bill.getCost(),
                        ReadFromFile.dateInputFormatter.format(bill.getFromDate()),
                        ReadFromFile.dateInputFormatter.format(bill.getToDate()),
                        bill.getCost()* bill.getQuantity()));
                totalCost += bill.getCost() * bill.getQuantity();
            }
            writer.append("\nTotal Cost: " + totalCost + "\n\n");
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
}
