public class Academician extends Personnel{
    int baseSalary = 2600;
    int ssBenefits;

    Academician(String name, String surname, String registrationNumber, String position, int yearOfStart, int[] workHours) {
        super(name, surname, registrationNumber, position, yearOfStart, workHours);
    }
}
