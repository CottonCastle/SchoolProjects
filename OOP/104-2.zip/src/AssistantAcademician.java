public class AssistantAcademician extends Academician {

    AssistantAcademician(String name, String surname, String registrationNumber, String position, int yearOfStart, int[] workHours) {
        super(name, surname, registrationNumber, position, yearOfStart, workHours);
        ssBenefits = 105;
    }

    @Override
    public int getSalary() {
        return baseSalary + baseSalary * ssBenefits / 100 + getSeverancePay();
    }
}
