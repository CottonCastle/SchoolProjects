public class Chief extends FTEmployee {

    Chief(String name, String surname, String registrationNumber, String position, int yearOfStart, int[] workHours) {
        super(name, surname, registrationNumber, position, yearOfStart, workHours);
        maxHours = 8;
        paymentPerDay = 125;
        paymentPerHour = 15;
    }
}
