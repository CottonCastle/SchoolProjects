import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;

public class DataIO {
    public static String[] readFile(String path) {
        try {
            int i = 0;
            int length = Files.readAllLines(Paths.get(path)).size();
            String[] results = new String[length];

            for (String line: Files.readAllLines(Paths.get(path))) {
                results[i++] = line;
            }

            return results;
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        }
    }

    // Output job
    public static void writeSalary(Personnel personnel) {
        try {
            BufferedWriter writer = new BufferedWriter(new FileWriter(personnel.registrationNumber));
            writer.write(String.format(
                            "Name : %s\n\n" +
                            "Surname : %s\n\n" +
                            "Registration Number : %s\n\n" +
                            "Position : %s\n\n" +
                            "Year of Start : %d\n\n" +
                            "Total Salary : %d.00 TL",
                    personnel.name, personnel.surname, personnel.registrationNumber,
                    personnel.position, personnel.yearOfStart, personnel.getSalary()
            ));
            writer.close();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
}
