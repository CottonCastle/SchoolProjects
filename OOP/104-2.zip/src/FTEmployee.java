public class FTEmployee extends Personnel {

    final int dayOfWork = 20;
    int paymentPerDay;
    int paymentPerHour;
    int maxHours;

    FTEmployee(String name, String surname, String registrationNumber, String position, int yearOfStart, int[] workHours) {
        super(name, surname, registrationNumber, position, yearOfStart, workHours);
    }

    @Override
    public int getSalary() {
        return getOverWorkHours() * paymentPerHour + dayOfWork * paymentPerDay + getSeverancePay();
    }

    private int getOverWorkHours() {
        int hours = 0;
        for (int hour: workHours) {
            if (hour > 40 + maxHours) {
                hour = 40 + maxHours;
            }
            hours += hour - 40;
        }
        return hours;
    }
}
