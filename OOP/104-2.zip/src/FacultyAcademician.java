public class FacultyAcademician extends Academician {
    private final int addCourseFee = 20;
    private final int maxHours = 8;

    FacultyAcademician(String name, String surname, String registrationNumber, String position, int yearOfStart, int[] workHours) {
        super(name, surname, registrationNumber, position, yearOfStart, workHours);
        ssBenefits = 135;
    }

    @Override
    public int getSalary() {
        return baseSalary + (baseSalary * ssBenefits / 100) + getSeverancePay() + getTotalAddCourseFee();
    }

    private int getTotalAddCourseFee() {
        int totalFee = 0;
        for (int hours: workHours) {
            int paidHours = hours - 40;
            if(paidHours > maxHours) {
                paidHours = maxHours;
            }
            totalFee += paidHours * addCourseFee;
        }
        return totalFee;
    }
}
