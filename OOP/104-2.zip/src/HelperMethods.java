public class HelperMethods {    //Minor useful methods to save time and code length
    /*
    getInputData: Returns a 2D array of the given personnel file path
    searchNGetMonitoring: Helps to get monitoring by the given file argument
    checkDuplicatePaths: Checks if there are any personnel with same ID
    popFirst: Cuts the array by its first element
    turnStringsToInts: Parses all of them
     */
    public static String[][] getInputData(String path) {
        String[] lines = DataIO.readFile(path);
        String[][] data = new String[lines.length][];
        for (int i = 0; i < lines.length; i++) {
            data[i] = lines[i].split("\t");
        }
        return data;
    }

    public static int[] searchNGetMonitoring(String registerNumber, String[][] monitoringData) {
        boolean foundInfo = false;
        int[] monitoring = new int[monitoringData.length-1];
        for (String[] data: monitoringData) {
            if (data[0].equals(registerNumber)) {
                monitoring = turnStringsToInts(popFirst(data));
                foundInfo = true;
                break;
            }
        }
        if (!foundInfo) {
            throw new RuntimeException("Can't find monitoring for a personnel");
        }
        return monitoring;
    }

    public static String[] popFirst(String[] array) {
        String[] newArray = new String[array.length-1];
        System.arraycopy(array, 1, newArray, 0, array.length - 1);
        return newArray;
    }

    public static int[] turnStringsToInts(String[] array) {
        int[] newArray = new int[array.length];
        for (int i = 0; i < array.length; i++) {
            newArray[i] = Integer.parseInt(array[i]);
        }
        return newArray;
    }
}
