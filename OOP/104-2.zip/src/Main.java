public class Main {
    public static void main(String[] args) {
        String personnelPath = args[0];
        String monitoringPath = args[1];
        Personnel[] personnelPool = MainMethods.createPersonnel(personnelPath, monitoringPath);
        // Creates personnel and their info to be worked on by using polymorphism
        for (Personnel personnel: personnelPool) {  // Creates all the output files
            DataIO.writeSalary(personnel);
        }
    }
}