public class MainMethods {  // Only one method is enough here
    public static Personnel[] createPersonnel(String personnelPath, String monitoringPath) {
        String[][] personnelInput = HelperMethods.getInputData(personnelPath);
        String[][] monitoringInput = HelperMethods.getInputData(monitoringPath);
        Personnel[] personnels = new Personnel[personnelInput.length];
        for (int i = 0; i < personnelInput.length; i++) {
            String[] personnel = personnelInput[i];
            String[] name_surname = personnel[0].split(" ");
            switch (personnel[2]) { // It did not take me too much time to realize I could have made this shorter but here we go
                case "FACULTY_MEMBER":
                    personnels[i] = new FacultyAcademician(
                            name_surname[0],                // name
                            name_surname[1],                // surname
                            personnel[1],                   // registerNumber
                            personnel[2],                   // position
                            Integer.parseInt(personnel[3]), // yearOfStart
                            HelperMethods.searchNGetMonitoring(personnel[1], monitoringInput)
                            // workHours ^
                            );
                    break;
                case "RESEARCH_ASSISTANT":
                    personnels[i] = new AssistantAcademician(
                            name_surname[0],
                            name_surname[1],
                            personnel[1],
                            personnel[2],
                            Integer.parseInt(personnel[3]),
                            HelperMethods.searchNGetMonitoring(personnel[1], monitoringInput)
                    );
                    break;
                case "OFFICER":
                    personnels[i] = new Officer(
                            name_surname[0],
                            name_surname[1],
                            personnel[1],
                            personnel[2],
                            Integer.parseInt(personnel[3]),
                            HelperMethods.searchNGetMonitoring(personnel[1], monitoringInput)
                    );
                    break;
                case "SECURITY":
                    personnels[i] = new Security(
                            name_surname[0],
                            name_surname[1],
                            personnel[1],
                            personnel[2],
                            Integer.parseInt(personnel[3]),
                            HelperMethods.searchNGetMonitoring(personnel[1], monitoringInput)
                    );
                    break;
                case "PARTTIME_EMPLOYEE":
                    personnels[i] = new PTEmployee(
                            name_surname[0],
                            name_surname[1],
                            personnel[1],
                            personnel[2],
                            Integer.parseInt(personnel[3]),
                            HelperMethods.searchNGetMonitoring(personnel[1], monitoringInput)
                    );
                    break;
                case "CHIEF":
                    personnels[i] = new Chief(
                            name_surname[0],
                            name_surname[1],
                            personnel[1],
                            personnel[2],
                            Integer.parseInt(personnel[3]),
                            HelperMethods.searchNGetMonitoring(personnel[1], monitoringInput)
                    );
                    break;
                case "WORKER":
                    personnels[i] = new Worker(
                            name_surname[0],
                            name_surname[1],
                            personnel[1],
                            personnel[2],
                            Integer.parseInt(personnel[3]),
                            HelperMethods.searchNGetMonitoring(personnel[1], monitoringInput)
                    );
                    break;
            }
        }
        return personnels;
    }
}
