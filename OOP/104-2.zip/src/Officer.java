public class Officer extends Personnel{
    private final int maxHours = 10;
    private final int baseSalary = 2600;
    private final int ssBenefits = 65;

    Officer(String name, String surname, String registrationNumber, String position, int yearOfStart, int[] workHours) {
        super(name, surname, registrationNumber, position, yearOfStart, workHours);
    }

    @Override
    public int getSalary() {
        return baseSalary + ssBenefits * baseSalary / 100 + getSeverancePay() + getOverworkSalary();
    }

    private int getOverworkSalary() {
        int totalFee = 0;
        for (int hours: workHours) {
            int paidHours = hours - 40;
            if(paidHours > maxHours) {
                paidHours = maxHours;
            }
            totalFee += paidHours * 20;
        }
        return totalFee;
    }
}
