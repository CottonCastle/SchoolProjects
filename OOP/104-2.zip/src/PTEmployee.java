public class PTEmployee extends Personnel{

    private final int maxHours = 20;
    private final int minHours = 10;

    PTEmployee(String name, String surname, String registrationNumber, String position, int yearOfStart, int[] workHours) {
        super(name, surname, registrationNumber, position, yearOfStart, workHours);
    }

    @Override
    public int getSalary() {
        return getSeverancePay() + getPaidHours() * 18;
    }

    private int getPaidHours() {
        int hours = 0;
        for (int hour: workHours) {
            if (hour > maxHours) {
                hour = maxHours;
            }
            if (hour < minHours) {
                hour = 0;
            }
            hours += hour;
        }
        return hours;
    }
}
