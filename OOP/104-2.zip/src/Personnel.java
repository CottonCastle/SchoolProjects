public class Personnel {    // Parent class of all the other subclasses includes essential info for creating classes

    String name;
    String surname;
    String registrationNumber;
    String position;
    int yearOfStart;
    int currentYear = 2023;
    int[] workHours;

    Personnel(String name, String surname, String registrationNumber, String position, int yearOfStart, int[] workHours) {
        this.name = name;
        this.surname = surname;
        this.registrationNumber = registrationNumber;
        this.position = position;
        this.yearOfStart = yearOfStart;
        this.workHours = workHours;
    }

    public int getSalary() {
        return 0;
    }

    public int getSeverancePay() {
        return (currentYear - yearOfStart) * 16;
    }
}
