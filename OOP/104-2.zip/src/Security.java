public class Security extends Personnel{
    private final int transMoney = 120;
    private final int foodMoney = 240;
    private final int maxHours = 54;
    private final int minHours = 30;

    Security(String name, String surname, String registrationNumber, String position, int yearOfStart, int[] workHours) {
        super(name, surname, registrationNumber, position, yearOfStart, workHours);
    }

    @Override
    public int getSalary() {
        return getHourOfWork() * 10 + getSeverancePay() + transMoney + foodMoney;
    }

    private int getHourOfWork() {
        int hours = 0;
        for (int hour: workHours) {
            if (hour > maxHours) {
                hour = maxHours;
            }
            if (hour < minHours) {
                hour = 0;
            }
            hours += hour;
        }
        return hours;
    }
}
