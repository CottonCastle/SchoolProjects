public class Worker extends FTEmployee{

    Worker(String name, String surname, String registrationNumber, String position, int yearOfStart, int[] workHours) {
        super(name, surname, registrationNumber, position, yearOfStart, workHours);
        maxHours = 10;
        paymentPerDay = 105;
        paymentPerHour = 11;
    }
}
