public class AdditionalTasks extends AssessmentDecorator {

    public AdditionalTasks(Assessment assessment) {
        super(assessment);
    }

    @Override
    public String printTasks() {
        return assessment.printTasks() + "AdditionalTasks ";
    }

    @Override
    public int fee() {
        return assessment.fee() + 5;
    }

}
