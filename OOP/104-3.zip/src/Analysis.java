public class Analysis extends AssessmentDecorator{

    public Analysis(Assessment assessment) {
        super(assessment);
    }

    @Override
    public String printTasks() {
        return assessment.printTasks() + "Analysis ";
    }

    @Override
    public int fee() {
        return assessment.fee() + 10;
    }
}
