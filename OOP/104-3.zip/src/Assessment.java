public interface Assessment {

    String printTasks();

    int fee();

}
