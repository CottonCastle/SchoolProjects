public abstract class AssessmentDecorator implements Assessment {
    Assessment assessment;

    public AssessmentDecorator(Assessment assessment) {
        this.assessment = assessment;
    }

    @Override
    public String printTasks() {
        return assessment.printTasks();
    }

    @Override
    public int fee() {
        return assessment.fee();
    }
}
