public abstract class BaseAssessment implements Assessment {

    public abstract String printTasks();

    public abstract int fee();

}
