import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;


public class DAO {
    private static ArrayList<Student> students = new ArrayList<>();

    public static void launch() {
        for (String[] command: FileIO.getInputData()) {
            commandCall(command);
        }
    }

    public static void processStudentData() {
        String[][] data = FileIO.getStudentData();
        for (String[] info: data) {
            // Setting up and checking the ID
            int studentID = Integer.parseInt(info[0]);
            checkDuplicateID(studentID);
            // Setting Name and Surname up
            String[] nameSurname = info[1].split(" ");

            String name = nameSurname[0];
            String surname = nameSurname[1];
            // Setting Address and Phone Number up
            String address = info[2];
            String phoneNumber = info[3];

            Student student = new Student(studentID, name, surname, address, phoneNumber);

            students.add(student);
        }
    }

    public static void processEnrollmentData() {
        List<List<String>> data = FileIO.getEnrollmentData();
        for (List<String> info: data) {
            String[] IDs = info.get(0).split("\t");
            int enrollmentID = Integer.parseInt(IDs[0]);
            int studentID = Integer.parseInt(IDs[1]);
            boolean found = false;
            for (Student student: students) {
                if (student.getStudentID() == studentID) {
                    found = true;
                    student.setEnrollmentID(enrollmentID);
                    for (String assessments: info.subList(1, info.size())) {
                        String concrete = assessments.split("\t")[0];
                        Assessment assessment = returnConcrete(concrete);
                        if (assessments.split("\t").length > 1) {
                            String[] decorators = assessments.split("\t")[1].split(" ");
                            for (String decorator: decorators) {
                                assessment = decorate(assessment, decorator);
                            }
                        }
                        student.addAssessment(assessment);
                    }
                }
            }
            if (!found) {
                throw new RuntimeException("Cannot find student in enrollment process!");
            }
        }
    }

    private static void newStudent(String[] data) {
        // data example:
        // 5	Harun Gezici	536-8967812	Address: Tandogan 34 sk. 56/3
        // Setting up and checking the ID
        int studentID = Integer.parseInt(data[0]);
        checkDuplicateID(studentID);
        // Setting Name and Surname up
        String[] nameSurname = data[1].split(" ");
        String name = nameSurname[0];
        String surname = nameSurname[1];
        // Setting Address and Phone Number up
        String address = data[2];
        String phoneNumber = data[3];

        Student student = new Student(studentID, name, surname, address, phoneNumber);

        students.add(student);

        //50	Meryem Atas	654-2122121	Address: Emek 19 sk. 12/5
        FileIO.appendOutputFile(String.format("Student %d %s added", studentID, name));
        FileIO.appendStudentFile(String.format("%d\t%s %s\t%s\tAddress: %s",
                studentID, name, surname, phoneNumber, address));
    }

    private static void removeStudent(int ID) {
        boolean IDExists = false;
        Student targetStudent = null;
        for (Student student: students) {
            if (student.getStudentID() == ID) {

                int assessmentCount = student.getEnrollment().size();
                String studentName = student.getName();

                targetStudent = student;
                IDExists = true;

                FileIO.removeStudentFromFile(ID, assessmentCount);
                FileIO.appendOutputFile(String.format("Student %d %s removed", ID, studentName));

                break;
            }
        }
        if (!IDExists) {
            throw new RuntimeException("Cannot remove, ID does not exist!");
        } else {
            students.remove(targetStudent);
        }
    }

    private static void checkDuplicateID(int ID) {
        for (Student student: students) {
            if (student.getStudentID() == ID) {
                throw new RuntimeException("ERROR! Duplicate ID detected!");
            }
        }
    }

    private static void createEnrollment(String[] data) {
        int enrollmentID = Integer.parseInt(data[0]);
        int studentID = Integer.parseInt(data[1]);
        boolean IDExists = false;
        for (Student student: students) {
            if (student.getStudentID() == studentID) {
                if (!student.isEnrollmentOpen()) {
                    student.setEnrollmentID(enrollmentID);
                    student.setEnrollment(new ArrayList<>());
                    FileIO.appendOutputFile("CourseEnrollment " + enrollmentID + " created");
                    FileIO.appendEnrollmentFile("\n" + enrollmentID + "\t" + studentID);
                    student.setEnrollmentOpen(true);
                } else {
                    throw new RuntimeException("Cannot create, enrollment already exists!");
                }
                IDExists = true;
                break;
            }
        }
        if (!IDExists) {
            throw new RuntimeException("Cannot remove, ID does not exist!");
        }
    }

    private static Assessment decorate(Assessment inner, String type) {
        switch (type) {
            case "LiteratureReview":
                return new  LiteratureReview(inner);
            case "Analysis":
                return new Analysis(inner);
            case "QuestionSet":
                return new QuestionSet(inner);
            case "AdditionalTasks":
                return new AdditionalTasks(inner);
            default: throw new RuntimeException("Decoration failed caused by input");
        }
    }

    private static Assessment returnConcrete(String type) {
        switch (type) {
            case "Essaybased":
                return new EssayBasedAssessment();
            case "MultipleChoice":
                return new MultipleChoiceAssessment();
            default: throw new RuntimeException("Not a valid main assessment type!");
        }
    }

    private static void addAssessment(String[] data){
        boolean foundTheStudent = false;
        for (Student student: students) {
            if ((student.getEnrollmentID() != null) && (student.getEnrollmentID() == Integer.parseInt(data[0]))) {

                foundTheStudent = true;

                String[] assessmentData = Arrays.copyOfRange(data, 1, data.length);
                Assessment assessment = returnConcrete(assessmentData[0]);

                if (assessmentData.length > 4) {
                    // Raise an exception when there is more than 3 additional assessments
                    throw new RuntimeException("The maximum additional classes is three");
                } else if (assessmentData.length > 1) {
                    // Adding the additional assessments
                    for (String decType: Arrays.copyOfRange(assessmentData, 1, assessmentData.length)) {
                        assessment = decorate(assessment, decType);
                    }
                }
                student.addAssessment(assessment);
                FileIO.addAssessmentToFile(student.getEnrollmentID(), "\n" + assessment.printTasks());
                FileIO.appendOutputFile(String.format("%s assessment added to enrollment %d",
                        assessmentData[0], student.getEnrollmentID()));
                break;
            }
        }

        if (!foundTheStudent) {
            throw new RuntimeException("Can't find student in addAssessment method!");
        }
    }

    private static void totalFee(int enrollmentID) {
        boolean foundTheStudent = false;
        for (Student student: students) {
            if (student.isEnrollmentOpen() && student.getEnrollmentID() == enrollmentID) {
                foundTheStudent = true;

                int fee = 0;
                for (Assessment assessment: student.getEnrollment()) {
                    fee += assessment.fee();
                }

                FileIO.appendOutputFile("TotalFee for enrollment " + enrollmentID);

                for (Assessment assessment: student.getEnrollment()) {
                    FileIO.appendOutputFile("\t" + assessment.printTasks() + assessment.fee() + "$");
                }
                FileIO.appendOutputFile("\tTotal: " + fee + "$");
                break;
            }
        }

        if (!foundTheStudent) {
            throw new RuntimeException("Can't find student in totalFee method!");
        }
    }

    private static void listStudents() {
        FileIO.appendOutputFile("Student List:");
        for (Student student: students) {
            // Output example: 45 Arif Batar 563-95632569 Address: Balgat 1321 cd. 12/5
            FileIO.appendOutputFile(String.format("%d %s %s %s Address: %s",
                    student.getStudentID(),
                    student.getName(),
                    student.getSurname(),
                    student.getPhoneNumber(),
                    student.getAddress()
            ));
        }
    }

    public static void commandCall(String[] line) {
        switch (line[0]) {
            case "AddStudent":
                String address = line[4];
                if (line.length > 5) {
                    for (String addressInfo : Arrays.copyOfRange(line, 5, line.length)) {
                        address = address + " " + addressInfo;
                    }
                }
                newStudent(new String[]{line[1], line[2], line[3], address});
                break;
            case "RemoveStudent":
                removeStudent(Integer.parseInt(line[1]));
                break;
            case "CreateEnrollment":
                createEnrollment(new String[]{line[1], line[2]});
                break;
            case "AddAssessment":
                addAssessment(Arrays.copyOfRange(line, 1, line.length));
                break;
            case "TotalFee":
                totalFee(Integer.parseInt(line[1]));
                break;
            case "ListStudents":
                listStudents();
                break;
            default:
                throw new RuntimeException("The command given is not valid, Check the first element of the input lines!");
        }
    }
}
