public class EssayBasedAssessment extends BaseAssessment {

    @Override
    public String printTasks() {
        return "EssayBased ";
    }

    @Override
    public int fee() {
        return 10;
    }

}
