import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class FileIO {

    public static String enrollmentPath;
    public static String studentPath;
    public static String inputPath;

    private static BufferedWriter outputWriter;
    private static BufferedWriter enrollmentWriter;

    FileIO() {
        try {
            outputWriter = new BufferedWriter(new FileWriter("output.txt",true));
            enrollmentWriter = new BufferedWriter(new FileWriter(enrollmentPath, true));
            int i = 0;
            int length = Files.readAllLines(Paths.get(enrollmentPath)).size();
            String[] results = new String[length];

            for (String line: Files.readAllLines(Paths.get(enrollmentPath))) {
                results[i++] = line;
            }


        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    private static BufferedWriter writerMaker(String outputPath) {
        try {
            return new BufferedWriter(new FileWriter(outputPath, true));
        } catch (IOException e) {
            e.printStackTrace();
            throw new RuntimeException(e);
        }
    }

    public static String[][] getStudentData() {
        String[][] data = tabSeparator(readFile(studentPath));
        for (String[] line: data) {
            line[line.length - 1] = line[line.length - 1].substring(9);
        }
        return data;
    }

    public static List<List<String>> getEnrollmentData() {
        String[] lines = readFile(enrollmentPath);

        List<List<String>> data = new ArrayList<>();
        List<String> currentList = null;

        for (String line : lines) {
            // I hate regex stuff, I had so many attemps
            if (line.matches("^\\d+\\t.*")) { // Check if the line starts with a number
                if (currentList != null) {
                    data.add(currentList);
                }
                currentList = new ArrayList<>();
                currentList.add(line);
            } else {
                if (currentList != null) {
                    currentList.add(line);
                }
            }
        }
        if (currentList != null) {
            data.add(currentList);
        }
        return removeEmptyParts(data);
    }

    public static String[][] getInputData() {
        String[][] data = spaceSeparator(readFile(inputPath));
        int i = 0;
        for (String[] rawInfo: data) {
            if (rawInfo[0].equals("AddStudent")) {
                String[] info = Arrays.copyOfRange(rawInfo, 1, rawInfo.length);
                info[0] = rawInfo[0];
                info[1] = rawInfo[1];
                info[2] = rawInfo[2] + " " + rawInfo[3];
                data[i] = info;
            }
            i++;
        }
        return data;
    }

    private static String[] readFile(String path) {
        try {
            int i = 0;
            int length = Files.readAllLines(Paths.get(path)).size();
            String[] results = new String[length];

            for (String line: Files.readAllLines(Paths.get(path))) {
                results[i++] = line;
            }

            return results;
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        }
    }

    private static List<List<String>> removeEmptyParts(List<List<String>> list) {
        List<List<String>> newList = new ArrayList<>();
        for (List<String> sublist: list) {
            List<String> newSublist = new ArrayList<>();
            for (String str: sublist) {
                if (str.length() > 2) {
                    newSublist.add(str);
                }
            }
            newList.add(newSublist);
        }
        return newList;
    }

    private static void removeEmptyLines(String path) {
        Path pathToFile = Paths.get(path);

        try {
            // Read all lines, filter out the empty ones, and collect to a list
            List<String> nonEmptyLines = Files.lines(pathToFile)
                    .filter(line -> !line.trim().isEmpty())
                    .collect(Collectors.toList());

            // Write the non-empty lines back to the file
            Files.write(pathToFile, nonEmptyLines);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private static String[][] tabSeparator(String[] lines) {
        String[][] data = new String[lines.length][];
        int index = 0;
        for (String line: lines) {
            data[index] = line.split("\t");
            index++;
        }
        return data;
    }

    private static String[][] spaceSeparator(String[] lines) {
        String[][] data = new String[lines.length][];
        int index = 0;
        for (String line: lines) {
            data[index] = line.split(" ");
            index++;
        }
        return data;
    }

    public static void appendOutputFile(String text) {
        BufferedWriter writer = writerMaker("output.txt");
        try {
            writer.append(text);
            writer.newLine();
            writer.close();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    public static void clearOutputFile() {
        try {
            outputWriter.flush();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    public static void appendStudentFile(String text) {
        BufferedWriter writer = writerMaker(studentPath);
        try {
            writer.newLine();
            writer.append(text);
            writer.close();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    public static void appendEnrollmentFile(String text) {
        BufferedWriter writer = writerMaker(enrollmentPath);
        try {
            writer.append(text);
            writer.close();
            removeEmptyLines(enrollmentPath);
        } catch (IOException e) {
            throw new RuntimeException("Enroll append error");
        }
    }

    public static void addAssessmentToFile(int targetID, String addingText) {
        try {
            Stream<String> lines = Files.lines(Paths.get(enrollmentPath));
            List<String> textToAdd = lines.map(line -> line.startsWith(Integer.toString(targetID)) ? line + addingText
                    : line).collect(Collectors.toList()); // Funny try, made me lose a lotta time
            Files.write(Paths.get(enrollmentPath), textToAdd);
            lines.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static void removeStudentFromFile(int targetID, int assessmentCount) {
        try {
            List<String> linesEnrollment = Files.readAllLines(Paths.get(enrollmentPath));
            for (int i = 0; i < linesEnrollment.size(); ) {
                if (linesEnrollment.get(i).endsWith(Integer.toString(targetID))) {
                    int end = Math.min(i + assessmentCount + 1, linesEnrollment.size());
                    linesEnrollment.subList(i, end).clear();
                } else {
                    i++;
                }
            }

            List<String> linesStudent = Files.readAllLines(Paths.get(studentPath));
            linesStudent.removeIf(line -> line.startsWith(Integer.toString(targetID)));

            Files.write(Paths.get(enrollmentPath), linesEnrollment);
            Files.write(Paths.get(studentPath), linesStudent);
            removeEmptyLines(enrollmentPath);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
