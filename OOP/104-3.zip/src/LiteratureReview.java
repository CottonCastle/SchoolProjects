public class LiteratureReview extends AssessmentDecorator{

    public LiteratureReview(Assessment assessment) {
        super(assessment);
    }

    @Override
    public String printTasks() {
        return assessment.printTasks() + "LiteratureReview ";
    }

    @Override
    public int fee() {
        return assessment.fee() + 15;
    }
}
