public class Main {
    public static void main(String[] args) {

        FileIO.enrollmentPath = "courseEnrollment.txt";
        FileIO.studentPath = "student.txt";
        FileIO.inputPath = args[0];

        new FileIO();

        FileIO.clearOutputFile();
        DAO.processStudentData();
        DAO.processEnrollmentData();
        DAO.launch();
    }
}