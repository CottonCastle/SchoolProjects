public class MultipleChoiceAssessment extends BaseAssessment {

    @Override
    public String printTasks() {
        return "MultipleChoice ";
    }

    @Override
    public int fee() {
        return 15;
    }

}
