public class QuestionSet extends AssessmentDecorator {

    public QuestionSet(Assessment assessment) {
        super(assessment);
    }

    @Override
    public String printTasks() {
        return assessment.printTasks() + "QuestionSet ";
    }

    @Override
    public int fee() {
        return assessment.fee() + 7;
    }

}
