import java.util.ArrayList;


public class Student {
    private int studentID;
    private String name;
    private String surname;
    private String phoneNumber;
    private String address;
    private boolean enrollmentOpen = false;
    private ArrayList<Assessment> enrollment;
    private Integer enrollmentID;

    Student(int studentID, String name, String surname, String phoneNumber, String address) {
        setStudentID(studentID);
        setName(name);
        setSurname(surname);
        setPhoneNumber(phoneNumber);
        setAddress(address);
        setEnrollment(new ArrayList<>());
        setEnrollmentID(null);
    }

    public int getStudentID() {
        return studentID;
    }

    public void setStudentID(int studentID) {
        this.studentID = studentID;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getSurname() {
        return surname;
    }

    public void setSurname(String surname) {
        this.surname = surname;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public ArrayList<Assessment> getEnrollment() {
        return enrollment;
    }

    public void setEnrollment(ArrayList<Assessment> enrollment) {
        this.enrollment = enrollment;
    }

    public void addAssessment(Assessment assessment) {
        enrollment.add(assessment);
    }

    public Integer getEnrollmentID() {
        return enrollmentID;
    }

    public void setEnrollmentID(Integer enrollmentID) {
        this.enrollmentID = enrollmentID;
    }

    public boolean isEnrollmentOpen() {
        return enrollmentOpen;
    }

    public void setEnrollmentOpen(boolean enrollmentOpen) {
        this.enrollmentOpen = enrollmentOpen;
    }
}
