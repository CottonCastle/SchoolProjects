import java.io.*;
import java.nio.file.Files;
import java.nio.file.Paths;

public class FileIO {

    private static final String stackOutPath = "stackOut.txt";
    private static final String queueOutPath = "queueOut.txt";

    public static String[] readFile(String path) {
        try {
            int i = 0;
            int length = Files.readAllLines(Paths.get(path)).size();
            String[] results = new String[length];

            for (String line: Files.readAllLines(Paths.get(path))) {
                results[i++] = line;
            }

            return results;
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        }
    }

    public static Integer[] readStackQueueData(String path) {
        try {
            BufferedReader reader = new BufferedReader(new FileReader(path));
            String[] stringNumbers = reader.readLine().split(" ");
            Integer[] numbers = new Integer[stringNumbers.length];
            for (int i = 0; i < stringNumbers.length; i++) {
                numbers[i] = Integer.parseInt(stringNumbers[i]);
            }
            return numbers;
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        }
    }

    public static void overwriteFile(String text, String path) {
        try {
            BufferedWriter writer = new BufferedWriter(new FileWriter(path));
            writer.write(text);
            writer.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static void appendFile(String text, String path) {
        try {
            BufferedWriter writer = new BufferedWriter(new FileWriter(path, true));
            writer.append(text + "\n");
            writer.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static void queueOutAppend(String text) {
        appendFile(text, queueOutPath);
    }

    public static void stackOutAppend(String text) {
        appendFile(text, stackOutPath);
    }

    public static void clearOutputs() {
        try {
            BufferedWriter sWriter = new BufferedWriter(new FileWriter(stackOutPath));
            BufferedWriter qWriter = new BufferedWriter(new FileWriter(queueOutPath));

            sWriter.flush();
            qWriter.flush();

            sWriter.close();
            qWriter.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
