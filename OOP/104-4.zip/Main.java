public class Main {
    public static void main(String[] args) {
        FileIO.clearOutputs();

        Methods launch = new Methods(
                "stack.txt",
                "queue.txt",
                args[0]
        );

        launch.readCommands();

        launch.updateStackFile();
        launch.updateQueueFile();
    }
}