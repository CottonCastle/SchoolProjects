public class Methods {

    private String stackPath;
    private String queuePath;
    private String commandPath;
    private Stack stack;
    private Queue queue;

    Methods(String newStackPath, String newQueuePath, String newCommandPath) {
        setStackPath(newStackPath);
        setQueuePath(newQueuePath);
        setCommandPath(newCommandPath);
        stack = new Stack();
        Integer[] stackData = FileIO.readStackQueueData(stackPath);
        for (int i = stackData.length - 1; i > -1; i--) {
            stack.push(stackData[i]);
        }
        queue = new Queue();
        Integer[] queueData = FileIO.readStackQueueData(queuePath);
        for (int i: queueData) {
            queue.enqueue(i);
        }
    }

    public void readCommands() {
        String[] lines = FileIO.readFile(commandPath);
        for (String line: lines) {
            String[] pair = line.split(" ");
            switch (pair[0]) {
                case "S":
                    stackCommand(pair);
                    break;
                case "Q":
                    queueCommand(pair);
                    break;
                default:
                    throw new RuntimeException("Some stuff in readCommands");
            }
        }
    }

    private void stackCommand(String[] command) {
        switch (command[1]) {
            case "removeGreater":
                SQMethods.removeGreater(stack, Integer.parseInt(command[2]));
                break;
            case "calculateDistance":
                SQMethods.calculateDistance(stack);
                break;
            case "addOrRemove":
                SQMethods.addOrRemove(stack, Integer.parseInt(command[2]));
                break;
            case "reverse":
                SQMethods.reverse(stack, Integer.parseInt(command[2]));
                break;
            case "sortElements":
                SQMethods.sortElements(stack);
                break;
            case "distinctElements":
                SQMethods.distinctElements(stack);
                break;
            default:
                throw new RuntimeException("Unknown Stack Command!");
        }
    }

    private void queueCommand(String[] command) {
        switch (command[1]) {
            case "removeGreater":
                SQMethods.removeGreater(queue, Integer.parseInt(command[2]));
                break;
            case "calculateDistance":
                SQMethods.calculateDistance(queue);
                break;
            case "addOrRemove":
                SQMethods.addOrRemove(queue, Integer.parseInt(command[2]));
                break;
            case "reverse":
                SQMethods.reverse(queue, Integer.parseInt(command[2]));
                break;
            case "sortElements":
                SQMethods.sortElements(queue);
                break;
            case "distinctElements":
                SQMethods.distinctElements(queue);
                break;
            default:
                throw new RuntimeException("Unknown Queue Command!");
        }
    }

    public void updateStackFile() {
        FileIO.overwriteFile(SQMethods.getStringOfStack(stack), stackPath);
    }

    public void updateQueueFile() {
        FileIO.overwriteFile(SQMethods.getStringOfQueue(queue), queuePath);
    }

    public void setStackPath(String stackPath) {
        this.stackPath = stackPath;
    }

    public void setQueuePath(String queuePath) {
        this.queuePath = queuePath;
    }

    public void setCommandPath(String commandPath) {
        this.commandPath = commandPath;
    }
}
