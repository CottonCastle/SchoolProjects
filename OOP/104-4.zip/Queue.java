public class Queue {
    private int[] queue;
    private int size;
    private int front;
    private int rear;

    public Queue() { // Implementation according to the 201 class
        queue = new int[0];
        size = 0;
        front = 0;
        rear = -1;
    }

    public void enqueue(int item) {
        if (size == queue.length) {
            resizeQueue();
        }
        rear = (rear + 1) % queue.length;
        queue[rear] = item;
        size++;
    }

    private void resizeQueue() {
        int newSize = size > 0 ? size * 2 : 1;
        int[] newQueue = new int[newSize];

        for (int i = 0; i < size; i++) {
            newQueue[i] = queue[(front + i) % queue.length];
        }

        queue = newQueue;
        front = 0;
        rear = size - 1;
    }

    public int poll() {
        if (isEmpty()) {
            return -1;
        }
        int item = queue[front];
        front = (front + 1) % queue.length;
        size--;
        return item;
    }

    public int dequeue() {
        if (isEmpty()) {
            throw new RuntimeException("Queue is empty, GO DEBUG");
        }
        int item = queue[front];
        front = (front + 1) % queue.length;
        size--;
        return item;
    }

    public int peek() {
        if (isEmpty()) {
            throw new RuntimeException("Queue is empty, GO DEBUG");
        }
        return queue[front];
    }

    public boolean isEmpty() {
        return size == 0;
    }

    public int size() {
        return size;
    }

    int[] getQueueList() {
        return queue;
    }
}
