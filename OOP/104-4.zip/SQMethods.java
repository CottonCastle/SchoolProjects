public class SQMethods {

    // DATA OPERATION METHODS

    // REMOVE GREATER

    public static void removeGreater(Stack stack, Integer number) {
        Stack tempStack = new Stack();
        // adding only the numbers lower than or equal to the given number
        while (!stack.isEmpty()) {
            int popNumber = stack.pop();
            if (popNumber <= number) {
                tempStack.push(popNumber);
            }
        }
        // reversing
        while (!tempStack.isEmpty()) {
            stack.push(tempStack.pop());
        }

        FileIO.stackOutAppend("After removeGreater " + number + ":\n" +
                getStringOfStack(stack)
        );
    }

    // Format Example:
    // After removeGreater 1:
    // 6 1 45 2 3 9 3 5 24 25 8 35 41 19 72 56

    public static void removeGreater(Queue queue, int number) {
        Queue tempQueue = new Queue();

        while (!queue.isEmpty()) {
            int current = queue.dequeue();
            if (current <= number) {
                tempQueue.enqueue(current);
            }
        }

        while (!tempQueue.isEmpty()) {
            queue.enqueue(tempQueue.dequeue());
        }
        // No reversing needed since it's a queue
        FileIO.queueOutAppend("After removeGreater " + number + ":\n" +
                getStringOfQueue(queue)
        );
    }

    // CALCULATE DISTANCE

    public static void calculateDistance(Stack stack) {
        int sum = 0;
        Stack tempStack = new Stack();

        while (!stack.isEmpty()) {
            int current = stack.pop();

            for (int num : stack.getStackList()) {
                sum += Math.abs(current - num);
            }

            tempStack.push(current);
        }

        while (!tempStack.isEmpty()) {
            stack.push(tempStack.pop());
        }

        FileIO.stackOutAppend("After calculateDistance:\n" +
                "Total distance=" + sum
        );
    }

    // Format Example:
    // After calculateDistance:
    // Total distance=2644

    public static void calculateDistance(Queue queue) {
        int sum = 0;
        Queue tempQueue = new Queue();
        int size = queue.size();
        for (int i = 0; i < size; i++) { // COPY
            int number = queue.dequeue();
            tempQueue.enqueue(number);
            queue.enqueue(number);
        }

        while (!tempQueue.isEmpty()) {
            int current = tempQueue.poll();

            for (int num : tempQueue.getQueueList()) {
                sum += Math.abs(current - num);
            }
        }

        FileIO.queueOutAppend("After calculateDistance:\n" +
                "Total distance=" + sum
        );
    }

    // ADD OR REMOVE

    public static void addOrRemove(Stack stack, Integer number) {

        int count = Math.abs(number);
        if (number > 0) {
            for (int i = 0; i < count; i++) {
                stack.push(getRandomNum());
            }
        } else if (number < 0) {
            for (int i = 0; i < count; i++) {
                stack.pop();
            }
        }

        FileIO.stackOutAppend("After addOrRemove " + number + ":\n" +
                getStringOfStack(stack)
        );
    }

    public static void addOrRemove(Queue queue, Integer number) {
        int count = Math.abs(number);
        if (number > 0) {
            for (int i = 0; i < count; i++) {
                queue.enqueue(getRandomNum());
            }
        } else if (number < 0) {
            for (int i = 0; i < count; i++) {
                queue.dequeue();
            }
        }

        FileIO.queueOutAppend("After addOrRemove " + number + ":\n" +
                getStringOfQueue(queue)
        );
    }

    // REVERSE

    public static void reverse(Stack stack, Integer number) {
        Queue tempQueue = new Queue();
        for (int i = 0; i < number; i++) {
            tempQueue.enqueue(stack.pop());
        }
        while (!tempQueue.isEmpty()) {
            stack.push(tempQueue.dequeue());
        }

        FileIO.stackOutAppend("After reverse " + number + ":\n" +
                getStringOfStack(stack)
        );
    }

    public static void reverse(Queue queue, Integer number) {
        Stack stack = new Stack();

        for (int i = 0; i < number; i++) {
            stack.push(queue.dequeue());
        }

        while (!stack.isEmpty()) {
            queue.enqueue(stack.pop());
        }

        for (int i = 0; i < (queue.size() - number); i++) {
            queue.enqueue(queue.dequeue());
        }

        FileIO.queueOutAppend("After reverse " + number + ":\n" +
                getStringOfQueue(queue)
        );
    }

    // SORTING

    public static void sortElements(Stack stack) {
        Stack tempStack = new Stack();

        while (!stack.isEmpty()) {
            int current = stack.pop();

            while (!tempStack.isEmpty() && tempStack.peek() > current) {
                stack.push(tempStack.pop());
            }

            tempStack.push(current);
        }

        while (!tempStack.isEmpty()) {
            stack.push(tempStack.pop());
        }

        FileIO.stackOutAppend("After sortElements:\n" +
                getStringOfStack(stack));
    }

    public static void sortElements(Queue queue) {
        int size = queue.size();

        for (int i = 0; i < size; i++) {
            int minIndex = -1;
            int minValue = Integer.MAX_VALUE;
            int currentSize = queue.size();

            for (int j = 0; j < currentSize; j++) {
                int current = queue.poll();
                if (current <= minValue && j <= size - i - 1) {
                    minValue = current;
                    minIndex = j;
                }
                queue.enqueue(current);
            }

            for (int j = 0; j < currentSize; j++) {
                int current = queue.poll();
                if (j != minIndex) {
                    queue.enqueue(current);
                }
            }
            queue.enqueue(minValue);
        }

        FileIO.queueOutAppend("After sortElements:\n" +
                getStringOfQueue(queue));
    }

    // DISTINCT ELEMENTS

    public static void distinctElements(Stack stack) {
        Stack tempStack = new Stack();
        Stack distinctElements = new Stack();
        Stack save = new Stack();

        while (!stack.isEmpty()) {
            int current = stack.pop();
            save.push(current);
            boolean isDistinct = true;
            while (!distinctElements.isEmpty()) {
                int element = distinctElements.pop();
                if (element == current) {
                    isDistinct = false;
                }
                tempStack.push(element);
            }

            while (!tempStack.isEmpty()) {
                distinctElements.push(tempStack.pop());
            }

            if (isDistinct) {
                distinctElements.push(current);
            }
        }

        while (!stack.isEmpty()) {
            stack.pop();
        }

        while (!save.isEmpty()) {
            stack.push(save.pop());
        }
        int count = distinctElements.size();

        FileIO.stackOutAppend("After distinctElements:\n" +
                "Total distinct element=" + count
        );
    }

    public static void distinctElements(Queue queue) { // hard with only stack and queue
        Stack tempStack = new Stack();
        Queue tempQueue = new Queue();
        Queue save = new Queue();
        int distinctCount = 0;

        while (!queue.isEmpty()) {
            int current = queue.dequeue();
            save.enqueue(current);
            boolean isDistinct = true;
            while (!tempStack.isEmpty()) {
                int element = tempStack.pop();
                if (element == current) {
                    isDistinct = false;
                }
                tempQueue.enqueue(element);
            }

            while (!tempQueue.isEmpty()) {
                tempStack.push(tempQueue.dequeue());
            }

            if (isDistinct) {
                distinctCount++;
                tempStack.push(current);
            }
        }

        while (!queue.isEmpty()) {
            queue.dequeue();
        }

        while (!save.isEmpty()) {
            queue.enqueue(save.dequeue());
        }

        FileIO.queueOutAppend("After distinctElements:\n" +
                "Total distinct element=" + distinctCount
        );
    }

    private static int getRandomNum() {
        return (int) (Math.random() * 51);
    }

    static String getStringOfStack(Stack stack) {
        Stack tempStack  = new Stack();
        String string = "";

        while (!stack.isEmpty()) {
            int number = stack.pop();
            tempStack.push(number);
            string += (number + " ");
        }

        while (!tempStack.isEmpty()) {
            stack.push(tempStack.pop());
        }

        return string;
    }

    static String getStringOfQueue(Queue queue) {
        String string = "";
        int size = queue.size();

        for (int i = 0; i < size; i++) {
            int number = queue.dequeue();
            queue.enqueue(number);
            string += (number + " ");
        }

        return string;
    }
}
