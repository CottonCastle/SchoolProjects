public class Stack {
    private int[] stack;
    private int size;

    public Stack() { // Implementation according to the 201 class
        stack = new int[0];
        size = 0;
    }

    public void push(int item) {
        if (size == stack.length) {
            resizeStack();
        }
        stack[size++] = item;
    }

    public int pop() {
        if (isEmpty()) {
            throw new IllegalStateException("Stack is empty");
        }
        int item = stack[--size];
        return item;
    }

    public int peek() {
        if (isEmpty()) {
            throw new IllegalStateException("Stack is empty");
        }
        return stack[size - 1];
    }

    public boolean isEmpty() {
        return size == 0;
    }

    public int size() {
        return size;
    }

    private void resizeStack() {
        int newSize = size > 0 ? size * 2 : 1;
        int[] newStack = new int[newSize];
        System.arraycopy(stack, 0, newStack, 0, size);
        stack = newStack;
    }
    public int[] getStackList() {
        return stack;
    }
}
